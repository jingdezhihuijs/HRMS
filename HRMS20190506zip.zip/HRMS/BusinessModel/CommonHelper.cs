﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataBaseAccessLib;

namespace BusinessModel
{

   public class CommonHelper
    {
       DBHelper dbHelper = new DBHelper();

       #region 人员考评管理

       /// <summary>
       /// 获取人员考评信息的列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetRykpInfoList(string strWhere)
       {
           string strSql = string.Format(@"SELECT   id, User_id, Depart_id, Kp_content, Kp_result, Score, datetime
                                           FROM     t_kp
                                           WHERE 1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += " AND  " + strWhere + " ";
           }
           DataTable dt_RykpuserInfo = dbHelper.GetDataTable(strSql);
           return dt_RykpuserInfo;
       }

       /// <summary>
       /// 获取人员考评信息的详细列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetRykpInfoListDetail(string strWhere)
       {
           string strSql = string.Format(@"SELECT T.*,T1.Name AS USERNAME,T1.User_code,T2.Depart_name FROM t_kp T 
                                            LEFT JOIN t_user T1 ON T.User_id = T1.ID
                                            LEFT JOIN t_depart T2 ON T.Depart_id = T2.id
                                            WHERE 1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql +=  strWhere ;
           }
           DataTable dt_RykpuserInfo = dbHelper.GetDataTable(strSql);
           return dt_RykpuserInfo;
       }
       /// <summary>
       /// 通过ID获取人员考评信息
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public DataTable GetRykpInfoByID(string id)
       {
           string strSql = string.Format(@"SELECT   id, User_id, Depart_id, Kp_content, Kp_result, Score,datetime
                                           FROM     t_kp
                                           WHERE id = '{0}'  ORDER BY datetime DESC ", id);
           DataTable dt_RykpuserInfo = dbHelper.GetDataTable(strSql);
           return dt_RykpuserInfo;
       }

       /// <summary>
       /// 通过ID获取人员考评信息
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public DataTable GetRykpInfoByUserId(string userid)
       {
           string strSql = string.Format(@"SELECT   id, User_id, Depart_id, Kp_content, Kp_result, Score,datetime
                                           FROM     t_kp
                                           WHERE User_id = '{0}'  ORDER BY datetime DESC ", userid);
           DataTable dt_RykpuserInfo = dbHelper.GetDataTable(strSql);
           return dt_RykpuserInfo;
       }

        #endregion

       #region 人员奖惩管理
       /// <summary>
       /// 获取人员奖惩信息的列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetRyjcInfoList(string strWhere)
       {
           string strSql = string.Format(@" SELECT  t.* 
                                            FROM     t_reward_punishement t
                                            WHERE 1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += " AND  " + strWhere + " ";
           }
           DataTable dt_RyjcuserInfo = dbHelper.GetDataTable(strSql);
           return dt_RyjcuserInfo;
       }

       /// <summary>
       /// 获取人员奖惩信息的详细列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetRyjcInfoListDetail(string strWhere)
       {
           string strSql = string.Format(@"SELECT  t.* ,t1.Name as userName, t2.Depart_name,t3.job_name
                                            FROM     t_reward_punishement t
                                            LEFT JOIN t_user     t1 on t.User_id = t1.Id
                                            left join t_depart   t2 on t.Depart_id = t2.id 
                                            left join t_job      t3 on t.Job_id = t3.id
                                            WHERE 1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += strWhere;
           }
           DataTable dt_RyjcuserInfo = dbHelper.GetDataTable(strSql);
           return dt_RyjcuserInfo;
       }
       /// <summary>
       /// 通过ID获取人员奖惩信息
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public DataTable GetRyjcInfoByID(string id)
       {
           string strSql = string.Format(@"SELECT  id, User_id, Depart_id, Job_id, Type, datetime, Money, Reason
                                           FROM    t_reward_punishement t
                                           WHERE   id = '{0}' ", id);
           DataTable dt_RyjcuserInfo = dbHelper.GetDataTable(strSql);
           return dt_RyjcuserInfo;
       }
       #endregion

       #region 员工培训管理

       /// <summary>
       /// 获取人员考评信息的列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetYgpxInfoList(string strWhere)
       {
           string strSql = string.Format(@"SELECT  ROW_NUMBER() OVER ( ORDER BY Start_date DESC  ) AS ROWNUM ,  id, User_id, Train_content, Score, Addr, Start_date, End_date
                                           FROM    t_train
                                           WHERE   1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += strWhere ;
           }
           DataTable dt_YgpxUserInfo = dbHelper.GetDataTable(strSql);
           return dt_YgpxUserInfo;
       }

       /// <summary>
       /// 获取员工培训的详细列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetYgpxInfoListDetail(string strWhere)
       {
           string strSql = string.Format(@"SELECT   ROW_NUMBER() OVER ( ORDER BY T.Start_date DESC  ) AS ROWNUM , 
                                                    T.id, 
                                                    T.User_id, 
		                                            T.Train_content, 
		                                            T.Score, 
		                                            T.Addr, 
		                                            T.Start_date, 
		                                            T.End_date,
		                                            T1.Name AS UserName
                                        FROM        t_train T 
                                                    LEFT JOIN t_user T1 ON T.User_id = T1.Id
                                        WHERE       1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += strWhere;
           }
           DataTable dt_YgpxUserInfo = dbHelper.GetDataTable(strSql);
           return dt_YgpxUserInfo;
       }
       /// <summary>
       /// 通过ID获取员工培训信息
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public DataTable GetYgpxInfoByID(string id)
       {
           string strSql = string.Format(@" SELECT id, User_id, Train_content, Score, Addr, Start_date, End_date
                                           FROM     t_train
                                           WHERE id = '{0}'  ORDER BY End_date DESC ", id);
           DataTable dt_YgpxUserInfo = dbHelper.GetDataTable(strSql);
           return dt_YgpxUserInfo;
       }
       #endregion

       #region 劳保福利管理

       /// <summary>
       /// 获取劳保福利信息的列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetFlffInfoList(string strWhere)
       {
           string strSql = string.Format(@"SELECT   ROW_NUMBER() OVER ( ORDER BY datetime DESC  ) AS ROWNUM , id, User_id, datetime, reason, Money
                                           FROM     t_fl
                                           WHERE    1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += " AND  " + strWhere + " ";
           }
           DataTable dt_FlffInfo = dbHelper.GetDataTable(strSql);
           return dt_FlffInfo;
       }

       /// <summary>
       /// 获取劳保福利信息的详细列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetFlffInfoListDetail(string strWhere)
       {
           string strSql = string.Format(@"SELECT  ROW_NUMBER() OVER ( ORDER BY t.datetime DESC  ) AS ROWNUM ,  T.*,T1.Name AS USERNAME,T1.User_code  
                                           FROM      t_fl T 
                                                     LEFT JOIN t_user T1 ON T.User_id = T1.ID
                                           WHERE     1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += strWhere;
           }
           DataTable dt_FlffInfo = dbHelper.GetDataTable(strSql);
           return dt_FlffInfo;
       }

       /// <summary>
       /// 通过ID获取劳保福利信息
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public DataTable GetFlffInfoByID(string id)
       {
           string strSql = string.Format(@"SELECT   id, User_id, datetime, reason, Money
                                           FROM     t_fl
                                           WHERE id = '{0}'  ORDER BY datetime DESC ", id);
           DataTable dt_FlffInfo = dbHelper.GetDataTable(strSql);
           return dt_FlffInfo;
       }

       /// <summary>
       /// 通过ID获取劳保福利信息
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public DataTable GetFlffInfoById(string userid)
       {
           string strSql = string.Format(@"SELECT   id, User_id, datetime, reason, Money
                                           FROM     t_fl
                                           WHERE    id= '{0}'  ORDER BY datetime DESC ", userid);
           DataTable dt_FlffInfo = dbHelper.GetDataTable(strSql);
           return dt_FlffInfo;
       }

       #endregion

       #region 人员调动管理

       /// <summary>
       /// 获取人员调动信息的列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetRyddInfoList(string strWhere)
       {
           string strSql = string.Format(@"SELECT  ROW_NUMBER() OVER ( ORDER BY datetime DESC  ) AS ROWNUM ,   id, User_id, datetime, Old_depart, New_depart, Old_job, New_job, name
                                           FROM    t_Dispatch
                                           WHERE   1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += strWhere;
           }
           DataTable dt_RyddInfo = dbHelper.GetDataTable(strSql);
           return dt_RyddInfo;
       }

       /// <summary>
       /// 获取人员调动的详细列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetRyddInfoListDetail(string strWhere)
       {
           string strSql = string.Format(@"SELECT   ROW_NUMBER() OVER ( ORDER BY T.datetime DESC  ) AS ROWNUM , 
                                                     T.id, 
                                                     T.User_id, 
                                                     T.datetime, 
                                                     T.Old_depart, 
                                                     T.New_depart, 
                                                     T.Old_job, 
                                                     T.New_job, 
                                                     T.name,
		                                             T1.Name AS UserName,
                                                     T1.User_code
                                        FROM        t_Dispatch T 
                                                    LEFT JOIN t_user T1 ON T.User_id = T1.Id
                                        WHERE       1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += strWhere;
           }
           DataTable dt_RyddInfo = dbHelper.GetDataTable(strSql);
           return dt_RyddInfo;
       }
       /// <summary>
       /// 通过ID获取员工调动信息
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public DataTable GetRyddInfoByID(string id)
       {
           string strSql = string.Format(@" SELECT  id, User_id, datetime, Old_depart, New_depart, Old_job, New_job, name
                                           FROM     t_Dispatch
                                           WHERE id = '{0}'  ORDER BY datetime DESC ", id);
           DataTable dt_RyddUserInfo = dbHelper.GetDataTable(strSql);
           return dt_RyddUserInfo;
       }
       #endregion

       #region 部门管理
       /// <summary>
       /// 获取部门信息
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetDeptInfoList(string strWhere)
       {
           string strSql = string.Format(@"SELECT  id, Depart_name, Depart_code, Parent_ID
 
                                           FROM     t_depart
                                           WHERE 1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += " AND  " + strWhere + " ";
           }
           DataTable dt_DeptInfo = dbHelper.GetDataTable(strSql);
           return dt_DeptInfo;
       }

       /// <summary>
       /// 获取部门信息列表
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetDeptInfoListDetail(string strWhere)
       {
           string strSql = string.Format(@"SELECT  T1.id, T1.Depart_name, T1.Depart_code, T1.Parent_ID,T2.Depart_name AS ParentName
                                            FROM     t_depart T1 
                                            LEFT JOIN t_depart T2 ON T1.Parent_ID = T2.id
                                           WHERE 1=1 ");
           if (strWhere.Trim() != "")
           {
               strSql += " AND  " + strWhere + " ";
           }
           DataTable dt_DeptInfo = dbHelper.GetDataTable(strSql);
           return dt_DeptInfo;
       }
       #endregion

       #region 用户管理
       /// <summary>
       /// 获取用户信息
       /// </summary>
       /// <param name="strWhere"></param>
       /// <returns></returns>
       public DataTable GetUserInfo(string strWhere)
       {
           string strSql = string.Format(@"SELECT ROW_NUMBER() OVER ( ORDER BY User_code asc  ) AS ROWNUM ,   *
 
                                           FROM     t_user
                                           WHERE UserName !='0' and UserName !='admin' ");
           if (strWhere.Trim() != "")
           {
               strSql += " AND   UserName='" + strWhere + "' ";
           }
           DataTable dt_UserInfo = dbHelper.GetDataTable(strSql);
           return dt_UserInfo;
       }
       #endregion

       #region 通用函数
       /// <summary>
       /// 编辑数据
       /// </summary>
       /// <param name="dt"></param>
       public void EditInfo(DataTable dt)
       {
           dbHelper.EditdataTable(dt);
       }

       /// <summary>
       /// 新增数据
       /// </summary>
       /// <param name="dt"></param>
       public void AddInfo(DataTable dt)
       {
           dbHelper.AdddataTable(dt);
       }

       /// <summary>
       /// 删除单条表数据
       /// </summary>
       /// <param name="tableName"></param>
       /// <param name="id"></param>
       public void DeleteInfo(string tableName, string id)
       {
           string strSql = " DELETE FROM  "+tableName+" WHERE ID = '"+id+"' ";
           dbHelper.ExecuteNonQuery(strSql);
       }

       /// <summary>
       /// 获取用户列表
       /// </summary>
       /// <returns></returns>
       public DataTable GetUsers()
       {
           string strSql = " Select *,User_code+'_'+name as CodeName from t_user where userName !='admin' order by User_code asc ";
           DataTable dt_users = dbHelper.GetDataTable(strSql);
           return dt_users;
       }

       /// <summary>
       /// 获取用户列表
       /// </summary>
       /// <returns></returns>
       public DataTable GetUsersDetail()
       {
           string strSql = @" Select *,User_code+'_'+name as CodeName ,t1.Depart_name,t2.Dict_name as jobName
                              from t_user t
                              left join   t_depart t1 on t.DepartId = t1.id 
                              left join   t_dict t2  on t.job_id = t2.id and t2.Parent_id='zhiwei'
                              where userName !='admin' order by User_code asc ";
           DataTable dt_users = dbHelper.GetDataTable(strSql);
           return dt_users;
       }

       /// <summary>
       /// 获取部门信息
       /// </summary>
       /// <returns></returns>
       public DataTable GetDepartment()
       {
           string strSql = " SELECT * FROM t_depart T ORDER BY ID ";
           DataTable dtDepartment = dbHelper.GetDataTable(strSql);
           return dtDepartment;
       }

       /// <summary>
       /// 获取职位信息
       /// </summary>
       /// <returns></returns>
       public DataTable GetJobInfo()
       {
           string strSql = @" SELECT  id, Dict_name, Dict_code, Type, Parent_id, Value
                              FROM     t_dict
                              WHERE   Parent_id = 'zhiwei'
                              ORDER BY  id asc  ";
           DataTable dtJob = dbHelper.GetDataTable(strSql);
           return dtJob;
       }


       #endregion

        #region 字典值

       /// <summary>
       /// 获取字典值
       /// </summary>
       /// <param name="strType"></param>
       /// <returns></returns>
        public DataTable GetDictInfo(string strType)
       {
           string strSql = string.Format(@"SELECT * FROM t_dict  T WHERE T.Type = 2 ");
           if (strType.Trim() != "")
           {
               strSql += " AND   T.Parent_id='" + strType + "' ";
           }
           DataTable dt_DictInfo = dbHelper.GetDataTable(strSql);
           return dt_DictInfo;
       }

        #endregion
    }
}
