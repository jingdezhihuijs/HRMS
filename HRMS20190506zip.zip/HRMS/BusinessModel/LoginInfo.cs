﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessModel
{
    public class LoginInfo
    {
        public static string UserID = "";
        public static string UserName = "";
        public static string Name = "";
    }
}
