﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataBaseAccessLib;
using System.Data;

namespace BusinessModel
{
   public class SkinSet
    {
       DBHelper dbHelper = new DBHelper();
        //添加皮肤设置
        public  void Pifu(string pifu)
        {
            string sql = string.Format("insert into t_Window(Skin) values('{0}')", pifu);
            dbHelper.ExecuteNonQuery(sql);
        }
        //查找皮肤
        public  DataTable SelectPifu()
        {
            string sql = string.Format("select * from t_Window");
            return dbHelper.GetDataTable(sql);
        }
        //删除皮肤表数据
        public  void DeletePifu()
        {
            string sql = string.Format("delete from t_Window");
            dbHelper.ExecuteNonQuery(sql);
        }
    }
}
