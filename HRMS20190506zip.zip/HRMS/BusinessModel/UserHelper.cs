﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataBaseAccessLib;

namespace BusinessModel
{
    public class  UserHelper
    {
        DBHelper dbHelper = new DBHelper();

        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="UserName">用户名</param>
        /// <param name="UserCode">用户编码</param>
        /// <param name="UserID">ID</param>
        /// <returns></returns>
        public DataTable GetUserInfo(string UserName, string UserCode)
        {
            string strSql = string.Format("SELECT * FROM t_user T WHERE T.Name ='{0}' AND T.User_code= '{1}'  ", UserName, UserCode);
            DataTable dt_userInfo =dbHelper.GetDataTable(strSql);
            return dt_userInfo;
        }

        /// <summary>
        /// 通过ID获取用户信息
        /// </summary>
        /// <param name="ID">用户ID</param>
        /// <returns></returns>
        public DataTable GetUserInfoById(string ID)
        {
            string strSql = string.Format("SELECT * FROM t_user T WHERE T.ID ='{0}'  ", ID);
            DataTable dt_userInfo = dbHelper.GetDataTable(strSql);
            return dt_userInfo;
        }

        /// <summary>
        /// 根据条件获取员工信息列表
        /// </summary>
        /// <param name="strWhere"></param>
        /// <returns></returns>
        public DataTable GetUserInfoList(string strWhere)
        {
            string strSql = string.Format(@"SELECT t.[Id]
                                            ,[User_code]
	                                        ,[Name]
	                                        ,[sex]
	                                        ,[nation]
	                                        ,[Title_tech]
	                                        ,[Edu]
                                            ,t.[Type]
                                            ,[ID_Card]
	                                        ,[Phone]
                                            ,[mobile]
	                                        ,td.[Depart_name]
	                                        ,tj.[Dict_name] as job_name
                                        FROM [t_user] t
                                        left join [t_depart] td on t.DepartId = td.id 
                                        left join [t_dict] tj on t.Job_id = tj.id
                                        WHERE 1=1 ");
            if (strWhere.Trim() != "")
            {
                strSql += strWhere + " ";
            }
            DataTable dt_userInfo = dbHelper.GetDataTable(strSql);
            return dt_userInfo;
        }

        /// <summary>
        /// 编辑数据
        /// </summary>
        /// <param name="dt"></param>
        public void EditUserInfo(DataTable dt)
        {
            dbHelper.EditdataTable(dt);
        }

        /// <summary>
        /// 新增数据
        /// </summary>
        /// <param name="dt"></param>
        public void AddUserInfo(DataTable dt)
        {
            dbHelper.AdddataTable(dt);
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="id">用户ID</param>
        public void DeleteUserInfo(string ID)
        {
            string strSql = " DELETE FROM t_user WHERE ID =  '" + ID + "'";
            dbHelper.ExecuteNonQuery(strSql);
        }

        public DataTable GetDepartments()
        {
            string strSql = " SELECT * FROM t_depart ";
            DataTable dt_Department= dbHelper.GetDataTable(strSql);
            return dt_Department;
        }
    }
}
