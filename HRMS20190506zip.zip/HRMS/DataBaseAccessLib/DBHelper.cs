﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseAccessLib
{
    public class DBHelper
    {
        //数据库链接字符串
        public static string ConnString = @"server=.\SQLEXPRESS;database=HRMS;uid=sa;pwd=000000;";
        //数据库链接对象
        private static SqlConnection Conn = null;

        protected SqlDataAdapter Da;
        protected SqlDataAdapter Da1;
        protected DataSet Ds;

        //初始化数据库链接
        private static void InitConnection()
        {
            if (Conn == null)
                Conn = new SqlConnection(ConnString);
            if (Conn.State == ConnectionState.Closed)
                Conn.Open();
            if (Conn.State == ConnectionState.Broken)
            {
                Conn.Close();
                Conn.Open();
            }
        }

        //查询，获取DataReader
        public static SqlDataReader GetDataReader(string sqlStr)
        {
            InitConnection();
            SqlCommand cmd = new SqlCommand(sqlStr, Conn);
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }

        //查询，获取DataSet
        public static DataSet GetDataSet(string sqlStr)
        {
            InitConnection();
            DataSet ds = new DataSet();
            SqlDataAdapter dap = new SqlDataAdapter(sqlStr, Conn);
            dap.Fill(ds);
            Conn.Close();
            return ds;

        }

        //查询，获取DataTable
        public  DataTable GetDataTable2(string sqlStr)
        {
            return GetDataSet(sqlStr).Tables[0];
        }

        //增改删
        public  bool ExecuteNonQuery(string sqlStr)
        {
            InitConnection();
            SqlCommand cmd = new SqlCommand(sqlStr, Conn);
            int result = cmd.ExecuteNonQuery();
            Conn.Close();
            return result > 0;
        }

        //执行集合函数
        public static object ExecuteScalar(string sqlStr)
        {
            InitConnection();
            SqlCommand cmd = new SqlCommand(sqlStr, Conn);
            object result = cmd.ExecuteScalar();
            Conn.Close();
            return result;
        }

        //查询数据表，修改用
        public DataTable GetDataTable(String SelectCmd)
        {
            Ds = new DataSet();
            Ds.Clear();
            DataTable DT = new DataTable();
            try
            {
                //执行的代码，其中可能有异常。一旦发现异常，则立即跳到catch执行。否则不会执行catch里面的内容
                Da = new SqlDataAdapter(SelectCmd, ConnString);
                Da.Fill(Ds);
                if (Ds.Tables.Count != 0)
                {
                    DT = Ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                //除非try里面执行代码发生了异常，否则这里的代码不会执行
                throw new Exception(ex.Message);
            }
            finally
            {
                //不管什么情况都会执行，包括try catch 里面用了return ,可以理解为只要执行了try或者catch，就一定会执行 finally 

            }
            return DT;
        }

        //添加数据库
        public DataTable AdddataTable(DataTable Dtable)
        {

            DataTable LTab;
            SqlCommandBuilder Cb = new SqlCommandBuilder(Da);
            DataTable DT = new DataTable();
            try
            {
                //执行的代码，其中可能有异常。一旦发现异常，则立即跳到catch执行。否则不会执行catch里面的内容
                LTab = Dtable.GetChanges(DataRowState.Added);
                if (LTab == null) { return null; }
                if (LTab.Rows.Count != 0)
                {
                    Da.Update(LTab);
                }
                Ds.Clear();
                Da.Fill(Ds);

                if (Ds.Tables.Count != 0)
                {
                    DT = Ds.Tables[0];
                }

            }
            catch (Exception ex)
            {
                //除非try里面执行代码发生了异常，否则这里的代码不会执行
                throw new Exception(ex.Message);
            }
            finally
            {
                //不管什么情况都会执行，包括try catch 里面用了return ,可以理解为只要执行了try或者catch，就一定会执行 finally 

            }
            return DT;
        }

        //修改数据库
        public DataTable EditdataTable(DataTable Dtable)
        {

            DataTable LTab;
            SqlCommandBuilder Cb = new SqlCommandBuilder(Da);
            DataTable DT = new DataTable();
            try
            {
                //执行的代码，其中可能有异常。一旦发现异常，则立即跳到catch执行。否则不会执行catch里面的内容
                LTab = Dtable.GetChanges(DataRowState.Modified);
                if (LTab == null) { return null; }
                if (LTab.Rows.Count != 0)
                {
                    Da.Update(LTab);
                }
                Ds.Clear();
                Da.Fill(Ds);

                if (Ds.Tables.Count != 0)
                {
                    DT = Ds.Tables[0];
                }

            }
            catch (Exception ex)
            {
                //除非try里面执行代码发生了异常，否则这里的代码不会执行
                throw new Exception(ex.Message);
            }
            finally
            {
                //不管什么情况都会执行，包括try catch 里面用了return ,可以理解为只要执行了try或者catch，就一定会执行 finally 

            }
            return DT;
        }


        //删除数据库
        public DataTable DeletedataTable(DataTable Dtable)
        {

            DataTable LTab;
            SqlCommandBuilder Cb = new SqlCommandBuilder(Da);
            DataTable DT = new DataTable();
            try
            {
                //执行的代码，其中可能有异常。一旦发现异常，则立即跳到catch执行。否则不会执行catch里面的内容
                LTab = Dtable.GetChanges(DataRowState.Deleted);
                if (LTab == null) { return null; }
                if (LTab.Rows.Count != 0)
                {
                    Da.Update(LTab);
                }
                Ds.Clear();
                Da.Fill(Ds);

                if (Ds.Tables.Count != 0)
                {
                    DT = Ds.Tables[0];
                }

            }
            catch (Exception ex)
            {
                //除非try里面执行代码发生了异常，否则这里的代码不会执行
                throw new Exception(ex.Message);
            }
            finally
            {
                //不管什么情况都会执行，包括try catch 里面用了return ,可以理解为只要执行了try或者catch，就一定会执行 finally 

            }
            return DT;
        }



    }
}
