﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataBaseAccessLib.EntityModel;


namespace HRMS
{
    class DictHelper
    {
        public Dict queryDictByCode(string code)
        {
            Dict dict = new Dict();



            return dict;
        }
    }
}
