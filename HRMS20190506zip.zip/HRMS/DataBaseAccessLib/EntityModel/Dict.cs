﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseAccessLib.EntityModel
{
   
    class Dict
    {
        public string Id { get; set; }
        public string Dict_name { get; set; }
        public string Dict_code { get; set; }
        public string Type { get; set; }
        public string Parent_id { get; set; }
        public string Value { get; set; }


    }
}
