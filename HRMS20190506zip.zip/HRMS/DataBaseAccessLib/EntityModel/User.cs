﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBaseAccessLib.EntityModel
{

    public class User
    {
        /// <summary>
        /// 用户ID
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string Usernme { get; set; }

        /// <summary>
        /// 用户密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 用户编码
        /// </summary>
        public string User_code { get; set; }

        /// <summary>
        /// 用户名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 性别
        /// </summary>
        public string sex { get; set; }

        /// <summary>
        /// 出生年月
        /// </summary>
        public string Date_of_birth { get; set; }

        /// <summary>
        /// 邮件
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// 民族
        /// </summary>
        public string nation { get; set; }

        /// <summary>
        /// 部门ID
        /// </summary>
        public string DepartId { get; set; }

        /// <summary>
        /// 职称
        /// </summary>
        public string Title_tech { get; set; }

        /// <summary>
        /// 职务
        /// </summary>
        public string Job_id { get; set; }

        /// <summary>
        /// 学历
        /// </summary>
        public string Edu { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// 手机
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 电话
        /// </summary>
        public string mobile { get; set; }

        /// <summary>
        /// 头像
        /// </summary>
        public string img { get; set; }

        /// <summary>
        /// 身份证号码
        /// </summary>
        public string ID_Card { get; set; }
    }
}
