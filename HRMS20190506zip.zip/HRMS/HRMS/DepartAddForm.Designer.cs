﻿namespace HRMS
{
    partial class DepartAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.llbSave = new System.Windows.Forms.LinkLabel();
            this.llbView = new System.Windows.Forms.LinkLabel();
            this.llbAdd = new System.Windows.Forms.LinkLabel();
            this.dgvDept = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.部门编码 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.部门名称 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.父部门名称 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Parent_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.cmbParent = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDept)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.llbSave);
            this.panel1.Controls.Add(this.llbView);
            this.panel1.Controls.Add(this.llbAdd);
            this.panel1.Location = new System.Drawing.Point(2, 18);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(986, 52);
            this.panel1.TabIndex = 0;
            // 
            // llbSave
            // 
            this.llbSave.AutoSize = true;
            this.llbSave.Location = new System.Drawing.Point(134, 16);
            this.llbSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbSave.Name = "llbSave";
            this.llbSave.Size = new System.Drawing.Size(44, 18);
            this.llbSave.TabIndex = 21;
            this.llbSave.TabStop = true;
            this.llbSave.Text = "保存";
            this.llbSave.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbSave_LinkClicked);
            // 
            // llbView
            // 
            this.llbView.AutoSize = true;
            this.llbView.Location = new System.Drawing.Point(75, 16);
            this.llbView.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbView.Name = "llbView";
            this.llbView.Size = new System.Drawing.Size(44, 18);
            this.llbView.TabIndex = 19;
            this.llbView.TabStop = true;
            this.llbView.Text = "查看";
            // 
            // llbAdd
            // 
            this.llbAdd.AutoSize = true;
            this.llbAdd.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.llbAdd.Location = new System.Drawing.Point(16, 16);
            this.llbAdd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbAdd.Name = "llbAdd";
            this.llbAdd.Size = new System.Drawing.Size(44, 18);
            this.llbAdd.TabIndex = 17;
            this.llbAdd.TabStop = true;
            this.llbAdd.Text = "增加";
            this.llbAdd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbAdd_LinkClicked);
            // 
            // dgvDept
            // 
            this.dgvDept.AllowUserToAddRows = false;
            this.dgvDept.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDept.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.部门编码,
            this.部门名称,
            this.父部门名称,
            this.Parent_ID});
            this.dgvDept.Location = new System.Drawing.Point(6, 152);
            this.dgvDept.Margin = new System.Windows.Forms.Padding(4);
            this.dgvDept.Name = "dgvDept";
            this.dgvDept.RowTemplate.Height = 23;
            this.dgvDept.Size = new System.Drawing.Size(981, 405);
            this.dgvDept.TabIndex = 1;
            this.dgvDept.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDept_CellClick);
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.Visible = false;
            // 
            // 部门编码
            // 
            this.部门编码.DataPropertyName = "Depart_code";
            this.部门编码.HeaderText = "部门编码";
            this.部门编码.Name = "部门编码";
            // 
            // 部门名称
            // 
            this.部门名称.DataPropertyName = "Depart_name";
            this.部门名称.HeaderText = "部门名称";
            this.部门名称.Name = "部门名称";
            // 
            // 父部门名称
            // 
            this.父部门名称.DataPropertyName = "ParentName";
            this.父部门名称.HeaderText = "父部门名称";
            this.父部门名称.Name = "父部门名称";
            // 
            // Parent_ID
            // 
            this.Parent_ID.DataPropertyName = "Parent_ID";
            this.Parent_ID.HeaderText = "Parent_ID";
            this.Parent_ID.Name = "Parent_ID";
            this.Parent_ID.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 100);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "部门名称：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(575, 102);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "父部门名称：";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(138, 96);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(148, 28);
            this.txtName.TabIndex = 4;
            // 
            // cmbParent
            // 
            this.cmbParent.FormattingEnabled = true;
            this.cmbParent.Location = new System.Drawing.Point(699, 98);
            this.cmbParent.Margin = new System.Windows.Forms.Padding(4);
            this.cmbParent.Name = "cmbParent";
            this.cmbParent.Size = new System.Drawing.Size(180, 26);
            this.cmbParent.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(314, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "部门编码：";
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(404, 96);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(151, 28);
            this.txtCode.TabIndex = 7;
            // 
            // DepartAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 588);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbParent);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvDept);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "DepartAddForm";
            this.Text = "添加部门信息";
            this.Load += new System.EventHandler(this.DepartAddForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDept)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel llbSave;
        private System.Windows.Forms.LinkLabel llbView;
        private System.Windows.Forms.LinkLabel llbAdd;
        private System.Windows.Forms.DataGridView dgvDept;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ComboBox cmbParent;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn 部门编码;
        private System.Windows.Forms.DataGridViewTextBoxColumn 部门名称;
        private System.Windows.Forms.DataGridViewTextBoxColumn 父部门名称;
        private System.Windows.Forms.DataGridViewTextBoxColumn Parent_ID;

    }
}