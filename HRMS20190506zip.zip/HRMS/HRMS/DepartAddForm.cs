﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class DepartAddForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        string dept_id = "";
        public DepartAddForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 绑定主表格数据
        /// </summary>
        public void DataBind()
        {
            DataTable dt_Dept = commonHelper.GetDeptInfoListDetail("");
            this.dgvDept.AutoGenerateColumns = false;
            this.dgvDept.DataSource = dt_Dept;
        }

        private void DepartAddForm_Load(object sender, EventArgs e)
        {
            DataTable dtDepartment = commonHelper.GetDepartment();
            if (dtDepartment.Rows.Count > 0)
            {
                cmbParent.DisplayMember = "Depart_name";
                cmbParent.ValueMember = "id";
                cmbParent.DataSource = dtDepartment;
                cmbParent.SelectedIndex = 0;
            }
            DataBind();
        }

        /// <summary>
        /// 增加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.txtName.Text.ToString().Trim() == "")
            {
                MessageBox.Show("部门名称不能为空！");
                return;
            }
            string deptName = this.txtName.Text.ToString();
            string deptCode = this.txtCode.Text.ToString();
            string parentid = this.cmbParent.SelectedValue.ToString();

            DataTable dt_DeptInfo = commonHelper.GetDeptInfoList("");
            //添加记录
            DataRow Nrow = dt_DeptInfo.NewRow();
            Nrow["Depart_name"] = deptName.Trim();
            Nrow["Depart_code"] = deptCode.Trim();
            Nrow["Parent_ID"] = parentid;
            dt_DeptInfo.Rows.Add(Nrow);
            commonHelper.AddInfo(dt_DeptInfo);
            MessageBox.Show("数据添加成功！");
            this.txtName.Text = "";
            this.txtCode.Text = "";
            DataBind();
        }

        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbSave_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.txtName.Text.ToString().Trim() == "")
            {
                MessageBox.Show("部门名称不能为空！");
                return;
            }
            string deptName = this.txtName.Text.ToString();
            string deptCode = this.txtCode.Text.ToString();
            string parentid = this.cmbParent.SelectedValue.ToString();
            string strSql = " ID = '" + dept_id + "' ";
            DataTable dt_DeptInfo = commonHelper.GetDeptInfoList(strSql);

            if (dt_DeptInfo.Rows.Count == 1)
            {
                //编辑记录
                dt_DeptInfo.Rows[0]["Depart_name"] = deptName.Trim();
                dt_DeptInfo.Rows[0]["Depart_code"] = deptCode.Trim();
                dt_DeptInfo.Rows[0]["Parent_ID"] = parentid;

                commonHelper.EditInfo(dt_DeptInfo);
                MessageBox.Show("数据保存成功！");
            }
        }

        /// <summary>
        /// 表格选择事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvDept_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //取出选中项的主键值
                int a = e.RowIndex;
                dept_id = dgvDept.Rows[a].Cells[0].Value.ToString();
                txtCode.Text = dgvDept.Rows[a].Cells[1].Value.ToString();
                txtName.Text = dgvDept.Rows[a].Cells[2].Value.ToString();
                cmbParent.SelectedValue = dgvDept.Rows[a].Cells[4].Value.ToString();
            }
            catch
            {
                MessageBox.Show("没有选中任何项！");
            }      
        }

    }
}
