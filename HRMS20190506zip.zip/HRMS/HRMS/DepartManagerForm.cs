﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class DepartManagerForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        public DepartManagerForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 增加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form addForm = new DepartAddForm();
            addForm.ShowDialog();
        }

        private void DepartManagerForm_Load(object sender, EventArgs e)
        {
            DataBind();
        }

        /// <summary>
        /// 绑定主表格数据
        /// </summary>
        public void DataBind()
        {
            string strSql = "";
            if (txtSearch.Text.ToString().Trim() != "")
            {
                strSql = string.Format(" AND ( T1.Depart_name LIKE '%{0}%' OR T1.Depart_code like '%{0}%' OR T2.Depart_name LIKE '%{0}%' ) ", txtSearch.Text.ToString().Trim());
            }
            DataTable dt_Dept = commonHelper.GetDeptInfoListDetail(strSql);
            this.dgvDept.AutoGenerateColumns = false;
            this.dgvDept.DataSource = dt_Dept;

            //判断是否有数据，有数据则将数量赋给数据量控件
            if (dt_Dept != null)
            {
                this.lblCount.Text = dt_Dept.Rows.Count.ToString();
            }
            else
            {
                this.lblCount.Text = "0";
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbDelete_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ///让用户选择是否删除
            MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
            if (MessageBox.Show("确定要删除数据吗？", "删除数据", btn) == DialogResult.Yes)
            {
                //取出选中行里面绑定的对象
                int a = dgvDept.CurrentRow.Index;
                string strId = dgvDept.Rows[a].Cells[0].Value.ToString();
                try
                {
                    commonHelper.DeleteInfo("t_depart", strId);
                    MessageBox.Show("删除成功！");
                    //确定删除的同时刷新数据
                    DataBind();
                }
                catch
                {
                    MessageBox.Show("删除失败！");
                }

            }
        }
        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataBind();
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbSearch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataBind();
        }
    }
}
