﻿namespace HRMS
{
    partial class FLAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.llbExit = new System.Windows.Forms.LinkLabel();
            this.llbPrint = new System.Windows.Forms.LinkLabel();
            this.llbSave = new System.Windows.Forms.LinkLabel();
            this.llbAdd = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbName = new System.Windows.Forms.ComboBox();
            this.txtMoney = new System.Windows.Forms.TextBox();
            this.dtpTime = new System.Windows.Forms.DateTimePicker();
            this.txtReason = new System.Windows.Forms.TextBox();
            this.dgvFlff = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.User_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.序号 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.员工名称 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.发放原因 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.发放时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.发放金额 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFlff)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.linkLabel5);
            this.panel1.Controls.Add(this.llbExit);
            this.panel1.Controls.Add(this.llbPrint);
            this.panel1.Controls.Add(this.llbSave);
            this.panel1.Controls.Add(this.llbAdd);
            this.panel1.Location = new System.Drawing.Point(18, 18);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(886, 48);
            this.panel1.TabIndex = 0;
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.Location = new System.Drawing.Point(285, 15);
            this.linkLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(44, 18);
            this.linkLabel5.TabIndex = 7;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "皮肤";
            // 
            // llbExit
            // 
            this.llbExit.AutoSize = true;
            this.llbExit.Location = new System.Drawing.Point(224, 15);
            this.llbExit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbExit.Name = "llbExit";
            this.llbExit.Size = new System.Drawing.Size(44, 18);
            this.llbExit.TabIndex = 6;
            this.llbExit.TabStop = true;
            this.llbExit.Text = "退出";
            this.llbExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbExit_LinkClicked);
            // 
            // llbPrint
            // 
            this.llbPrint.AutoSize = true;
            this.llbPrint.Location = new System.Drawing.Point(156, 15);
            this.llbPrint.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbPrint.Name = "llbPrint";
            this.llbPrint.Size = new System.Drawing.Size(44, 18);
            this.llbPrint.TabIndex = 5;
            this.llbPrint.TabStop = true;
            this.llbPrint.Text = "打印";
            // 
            // llbSave
            // 
            this.llbSave.AutoSize = true;
            this.llbSave.Location = new System.Drawing.Point(87, 15);
            this.llbSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbSave.Name = "llbSave";
            this.llbSave.Size = new System.Drawing.Size(44, 18);
            this.llbSave.TabIndex = 4;
            this.llbSave.TabStop = true;
            this.llbSave.Text = "保存";
            this.llbSave.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbSave_LinkClicked);
            // 
            // llbAdd
            // 
            this.llbAdd.AutoSize = true;
            this.llbAdd.Location = new System.Drawing.Point(21, 15);
            this.llbAdd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbAdd.Name = "llbAdd";
            this.llbAdd.Size = new System.Drawing.Size(44, 18);
            this.llbAdd.TabIndex = 3;
            this.llbAdd.TabStop = true;
            this.llbAdd.Text = "增加";
            this.llbAdd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbAdd_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 106);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "发放员工名称：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 147);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "发放福利时间：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(489, 105);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "福利发放金额：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 189);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "发放福利原因：";
            // 
            // cmbName
            // 
            this.cmbName.FormattingEnabled = true;
            this.cmbName.Location = new System.Drawing.Point(174, 100);
            this.cmbName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbName.Name = "cmbName";
            this.cmbName.Size = new System.Drawing.Size(180, 26);
            this.cmbName.TabIndex = 5;
            // 
            // txtMoney
            // 
            this.txtMoney.Location = new System.Drawing.Point(624, 98);
            this.txtMoney.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMoney.Name = "txtMoney";
            this.txtMoney.Size = new System.Drawing.Size(148, 28);
            this.txtMoney.TabIndex = 6;
            // 
            // dtpTime
            // 
            this.dtpTime.Location = new System.Drawing.Point(174, 140);
            this.dtpTime.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpTime.Name = "dtpTime";
            this.dtpTime.Size = new System.Drawing.Size(260, 28);
            this.dtpTime.TabIndex = 7;
            // 
            // txtReason
            // 
            this.txtReason.Location = new System.Drawing.Point(174, 189);
            this.txtReason.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtReason.Multiline = true;
            this.txtReason.Name = "txtReason";
            this.txtReason.Size = new System.Drawing.Size(598, 72);
            this.txtReason.TabIndex = 8;
            // 
            // dgvFlff
            // 
            this.dgvFlff.AllowUserToAddRows = false;
            this.dgvFlff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFlff.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.User_id,
            this.序号,
            this.员工名称,
            this.发放原因,
            this.发放时间,
            this.发放金额});
            this.dgvFlff.Location = new System.Drawing.Point(18, 286);
            this.dgvFlff.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvFlff.Name = "dgvFlff";
            this.dgvFlff.RowTemplate.Height = 23;
            this.dgvFlff.Size = new System.Drawing.Size(886, 368);
            this.dgvFlff.TabIndex = 9;
            this.dgvFlff.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFlff_CellClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Visible = false;
            // 
            // User_id
            // 
            this.User_id.DataPropertyName = "User_id";
            this.User_id.HeaderText = "User_id";
            this.User_id.Name = "User_id";
            this.User_id.Visible = false;
            // 
            // 序号
            // 
            this.序号.DataPropertyName = "ROWNUM";
            this.序号.HeaderText = "序号";
            this.序号.Name = "序号";
            // 
            // 员工名称
            // 
            this.员工名称.DataPropertyName = "UserName";
            this.员工名称.HeaderText = "员工名称";
            this.员工名称.Name = "员工名称";
            // 
            // 发放原因
            // 
            this.发放原因.DataPropertyName = "reason";
            this.发放原因.HeaderText = "发放原因";
            this.发放原因.Name = "发放原因";
            // 
            // 发放时间
            // 
            this.发放时间.DataPropertyName = "datetime";
            this.发放时间.HeaderText = "发放时间";
            this.发放时间.Name = "发放时间";
            // 
            // 发放金额
            // 
            this.发放金额.DataPropertyName = "Money";
            this.发放金额.HeaderText = "发放金额";
            this.发放金额.Name = "发放金额";
            // 
            // FLAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 672);
            this.Controls.Add(this.dgvFlff);
            this.Controls.Add(this.txtReason);
            this.Controls.Add(this.dtpTime);
            this.Controls.Add(this.txtMoney);
            this.Controls.Add(this.cmbName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FLAddForm";
            this.Text = "增加福利信息";
            this.Load += new System.EventHandler(this.FLAddForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFlff)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel llbPrint;
        private System.Windows.Forms.LinkLabel llbSave;
        private System.Windows.Forms.LinkLabel llbAdd;
        private System.Windows.Forms.LinkLabel llbExit;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbName;
        private System.Windows.Forms.TextBox txtMoney;
        private System.Windows.Forms.DateTimePicker dtpTime;
        private System.Windows.Forms.TextBox txtReason;
        private System.Windows.Forms.DataGridView dgvFlff;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn User_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn 序号;
        private System.Windows.Forms.DataGridViewTextBoxColumn 员工名称;
        private System.Windows.Forms.DataGridViewTextBoxColumn 发放原因;
        private System.Windows.Forms.DataGridViewTextBoxColumn 发放时间;
        private System.Windows.Forms.DataGridViewTextBoxColumn 发放金额;
    }
}