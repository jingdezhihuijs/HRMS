﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class FLAddForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        UserHelper userHelper = new UserHelper();
        string fl_id = "";
        public FLAddForm()
        {
            InitializeComponent();
        }

        private void FLAddForm_Load(object sender, EventArgs e)
        {
            DataBind();
            DataTable dt = commonHelper.GetUsers();
            if (dt.Rows.Count > 0)
            {
                cmbName.DisplayMember = "CodeName";
                cmbName.ValueMember = "id";
                cmbName.DataSource = dt;
                cmbName.SelectedIndex = 0;
            }
        }

        public FLAddForm(string id, string editType)
        {
            InitializeComponent();

            fl_id = id;
            DataTable dt = commonHelper.GetFlffInfoByID(id);
            if (dt.Rows.Count > 0)
            {
                cmbName.SelectedValue = dt.Rows[0]["User_id"].ToString();
                txtMoney.Text = dt.Rows[0]["Money"].ToString();
                txtReason.Text = dt.Rows[0]["reason"].ToString();
                dtpTime.Value = DateTime.Parse(dt.Rows[0]["datetime"].ToString());
            }
            else
            {
                MessageBox.Show("数据加载失败！");
            }

            if (editType == "View")
            {
                cmbName.Enabled   = false;
                txtMoney.Enabled  = false;
                txtReason.Enabled = false;
                dtpTime.Enabled   = false;
                llbAdd.Enabled    = false;
                llbSave.Enabled  = false;
            }
        }

        /// <summary>
        /// 绑定主表格数据
        /// </summary>
        public void DataBind()
        {
            string strSql = "";
            DataTable dt_FlffInfo = commonHelper.GetFlffInfoListDetail(strSql);
            this.dgvFlff.AutoGenerateColumns = false;
            this.dgvFlff.DataSource = dt_FlffInfo;
        }

        /// <summary>
        /// 增加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.cmbName.SelectedValue.ToString().Trim() == "")
            {
                MessageBox.Show("员工名称不能为空！");
                return;
            }
            if (this.txtMoney.Text.ToString().Trim() == "")
            {
                MessageBox.Show("福利发放金额不能为空！");
                return;
            }
            if (this.txtReason.Text.ToString().Trim() == "")
            {
                MessageBox.Show("福利发放原因不能为空！");
                return;
            }
          
            try
            {
                DataTable dt_FlffInfo = commonHelper.GetFlffInfoList("");
                //添加记录
                DataRow Nrow = dt_FlffInfo.NewRow();
                Nrow["User_id"] = this.cmbName.SelectedValue.ToString();
                Nrow["Money"] = this.txtMoney.Text.ToString().Trim();
                Nrow["reason"] = this.txtReason.Text.ToString().Trim();
                Nrow["datetime"] = this.dtpTime.Value.ToString("yyyy-MM-dd");
                dt_FlffInfo.Rows.Add(Nrow);
                commonHelper.AddInfo(dt_FlffInfo);
                MessageBox.Show("数据添加成功！");
                this.txtMoney.Text = "";
                this.txtReason.Text = "";
                DataBind();
            }
            catch { }
        }

        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbSave_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.cmbName.SelectedValue.ToString().Trim() == "")
            {
                MessageBox.Show("员工名称不能为空！");
                return;
            }
            if (this.txtMoney.Text.ToString().Trim() == "")
            {
                MessageBox.Show("福利发放金额不能为空！");
                return;
            }
            if (this.txtReason.Text.ToString().Trim() == "")
            {
                MessageBox.Show("福利发放原因不能为空！");
                return;
            }

            try
            {
                DataTable dt_FlffInfo = commonHelper.GetFlffInfoById(fl_id);

                if (dt_FlffInfo.Rows.Count == 1)
                {
                    //编辑记录
                    dt_FlffInfo.Rows[0]["User_id"] = this.cmbName.SelectedValue.ToString();
                    dt_FlffInfo.Rows[0]["Money"] = this.txtMoney.Text.ToString().Trim();
                    dt_FlffInfo.Rows[0]["reason"] = this.txtReason.Text.ToString().Trim();
                    dt_FlffInfo.Rows[0]["datetime"] = this.dtpTime.Value.ToString("yyyy-MM-dd");
                    commonHelper.EditInfo(dt_FlffInfo);
                    MessageBox.Show("数据保存成功！");
                    DataBind();
                    this.txtMoney.Text = "";
                    this.txtReason.Text = "";
                }                  
            }
            catch { }
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 元素选择事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvFlff_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //取出选中项的主键值
                int a = e.RowIndex;
                fl_id = dgvFlff.Rows[a].Cells[0].Value.ToString();
                cmbName.SelectedValue = dgvFlff.Rows[a].Cells[1].Value.ToString();
                txtMoney.Text = dgvFlff.Rows[a].Cells[6].Value.ToString();
                txtReason.Text = dgvFlff.Rows[a].Cells[4].Value.ToString();
                dtpTime.Value = DateTime.Parse(dgvFlff.Rows[a].Cells[5].Value.ToString());
            }
            catch
            {
                MessageBox.Show("没有选中任何项！");
            }      
        }

        
    }
}
