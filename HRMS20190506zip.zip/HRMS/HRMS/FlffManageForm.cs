﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class FlffManageForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        public FlffManageForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 窗体加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FlffManageForm_Load(object sender, EventArgs e)
        {
            DataBind();
        }

        /// <summary>
        /// 绑定主表格数据
        /// </summary>
        public void DataBind()
        {
            string strSql = "";
            if (txtSearch.Text.ToString().Trim() != "")
            {
                strSql = string.Format(" AND ( T1.Name LIKE '%{0}%' OR T.reason LIKE '%{0}%' OR T.Money LIKE '%{0}%'  ) ", txtSearch.Text.ToString().Trim());
            }
            DataTable dt_Flff = commonHelper.GetFlffInfoListDetail(strSql);
            this.dgvFlff.AutoGenerateColumns = false;
            this.dgvFlff.DataSource = dt_Flff;

            //判断是否有数据，有数据则将数量赋给数据量控件
            if (dt_Flff != null)
            {
                this.lblCount.Text = dt_Flff.Rows.Count.ToString();
            }
            else
            {
                this.lblCount.Text = "0";
            }
        }

        /// <summary>
        /// 增加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new FLAddForm().ShowDialog();
            DataBind();
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbEdit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //判断是否有选中项
            if (this.dgvFlff.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvFlff.CurrentRow.Index;
                string strId = dgvFlff.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                FLAddForm rf = new FLAddForm(strId, "Edit");
                //显示窗体
                rf.ShowDialog();
                DataBind();

            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            } 
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbDelete_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ///让用户选择是否删除
            MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
            if (MessageBox.Show("确定要删除数据吗？", "删除数据", btn) == DialogResult.Yes)
            {
                //取出选中行里面绑定的对象
                int a = dgvFlff.CurrentRow.Index;
                string strId = dgvFlff.Rows[a].Cells[0].Value.ToString();
                try
                {
                    commonHelper.DeleteInfo("t_fl", strId);
                    MessageBox.Show("删除成功！");
                    //确定删除的同时刷新数据
                    DataBind();
                }
                catch
                {
                    MessageBox.Show("删除失败！");
                }
            }
        }

        /// <summary>
        /// 查看
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbView_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //判断是否有选中项
            if (this.dgvFlff.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvFlff.CurrentRow.Index;
                string strId = dgvFlff.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                FLAddForm rf = new FLAddForm(strId, "View");
                //显示窗体
                rf.ShowDialog();
            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            } 
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.txtSearch.Text = "";
            DataBind();
        }

        /// <summary>
        /// 搜索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbSearch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataBind();
        }

    }
}
