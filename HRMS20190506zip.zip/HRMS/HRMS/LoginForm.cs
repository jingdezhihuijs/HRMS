﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;
using DataBaseAccessLib;

namespace HRMS
{
    public partial class LoginForm : Form
    {
        DBHelper dbHelper = new DBHelper();
        public LoginForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string loginName = this.txtUserName.Text;
            string loginPwd = this.txtPassword.Text;
            if (loginName == "")
            {
                MessageBox.Show("用户名不能为空!", "验证错误:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (loginPwd == "")
            {
                MessageBox.Show("密码不能为空!", "验证错误:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //根据用户名查询用户信息
            string sqlStr = string.Format("SELECT * FROM t_user T WHERE T.UserName ='{0}'", loginName);
            DataTable dt_userInfo = dbHelper.GetDataTable(sqlStr);
            if (dt_userInfo.Rows.Count == 0)
            {
                MessageBox.Show("用户不存在!", "登录失败:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (dt_userInfo.Rows[0]["Password"].ToString() != loginPwd)
            {
                MessageBox.Show("密码错误!", "登录失败:", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //登录成功保存登录信息
                LoginInfo.UserID = dt_userInfo.Rows[0]["id"].ToString();
                LoginInfo.UserName = dt_userInfo.Rows[0]["UserName"].ToString();
                LoginInfo.Name = dt_userInfo.Rows[0]["Name"].ToString();

                //根据用户ID查询用户角色
                string sqlStr2 = string.Format(@"select  tr.Role_name 
                                                 from    t_role tr 
                                                         left join t_user_role tur on tr.id = tur.Role_id
                                                 where   tur.User_id = '{0}'", LoginInfo.UserID);

                DataTable dt_userInfo2 = dbHelper.GetDataTable(sqlStr2);

                if (dt_userInfo2.Rows.Count == 0)
                {
                    MessageBox.Show("角色不存在!", "登录失败:", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else 
                {
                     MainForm mf = new MainForm();
                    //根据不同角色,打开不同界面
                     if (dt_userInfo2.Rows[0]["Role_name"].ToString() == "人事助理")
                     {
                         mf.Show();
                     }
                     else
                     {
                         mf.Show();
                     }

                    //隐藏登录窗体
                    this.Hide();
                }               
            }
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.txtUserName.Text = "";
            this.txtPassword.Text = "";
        }
    }
}
