﻿namespace HRMS
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.人事管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.员工档案管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.员工培训管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.员工奖惩管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人员调动管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.劳保福利发放ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人员考评管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人员信息统计ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.部门管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.用户管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.皮肤修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.重新登录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnDepartment = new System.Windows.Forms.Button();
            this.btnHrManage = new System.Windows.Forms.Button();
            this.btnUserManage = new System.Windows.Forms.Button();
            this.plHR = new System.Windows.Forms.Panel();
            this.btnRyxx = new System.Windows.Forms.Button();
            this.btnRydd = new System.Windows.Forms.Button();
            this.btnFyff = new System.Windows.Forms.Button();
            this.btnYgpx = new System.Windows.Forms.Button();
            this.btnRykp = new System.Windows.Forms.Button();
            this.btnJC = new System.Windows.Forms.Button();
            this.btnFile = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnUserAdd = new System.Windows.Forms.Button();
            this.btnPwdEdit = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnDepart = new System.Windows.Forms.Button();
            this.skinEngine1 = new Sunisoft.IrisSkin.SkinEngine(((System.ComponentModel.Component)(this)));
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.plHR.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.人事管理ToolStripMenuItem,
            this.部门管理ToolStripMenuItem,
            this.用户管理ToolStripMenuItem,
            this.设置ToolStripMenuItem,
            this.帮助ToolStripMenuItem,
            this.系统退出ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(827, 32);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 人事管理ToolStripMenuItem
            // 
            this.人事管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.员工档案管理ToolStripMenuItem,
            this.员工培训管理ToolStripMenuItem,
            this.员工奖惩管理ToolStripMenuItem,
            this.人员调动管理ToolStripMenuItem,
            this.劳保福利发放ToolStripMenuItem,
            this.人员考评管理ToolStripMenuItem,
            this.人员信息统计ToolStripMenuItem});
            this.人事管理ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuText;
            this.人事管理ToolStripMenuItem.Name = "人事管理ToolStripMenuItem";
            this.人事管理ToolStripMenuItem.Size = new System.Drawing.Size(94, 28);
            this.人事管理ToolStripMenuItem.Text = "人事管理";
            // 
            // 员工档案管理ToolStripMenuItem
            // 
            this.员工档案管理ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.员工档案管理ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.员工档案管理ToolStripMenuItem.Name = "员工档案管理ToolStripMenuItem";
            this.员工档案管理ToolStripMenuItem.Size = new System.Drawing.Size(200, 30);
            this.员工档案管理ToolStripMenuItem.Text = "员工档案管理";
            this.员工档案管理ToolStripMenuItem.Click += new System.EventHandler(this.btnFile_Click);
            // 
            // 员工培训管理ToolStripMenuItem
            // 
            this.员工培训管理ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.员工培训管理ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.员工培训管理ToolStripMenuItem.Name = "员工培训管理ToolStripMenuItem";
            this.员工培训管理ToolStripMenuItem.Size = new System.Drawing.Size(200, 30);
            this.员工培训管理ToolStripMenuItem.Text = "员工培训管理";
            this.员工培训管理ToolStripMenuItem.Click += new System.EventHandler(this.员工培训管理ToolStripMenuItem_Click);
            // 
            // 员工奖惩管理ToolStripMenuItem
            // 
            this.员工奖惩管理ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.员工奖惩管理ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.员工奖惩管理ToolStripMenuItem.Name = "员工奖惩管理ToolStripMenuItem";
            this.员工奖惩管理ToolStripMenuItem.Size = new System.Drawing.Size(200, 30);
            this.员工奖惩管理ToolStripMenuItem.Text = "员工奖惩管理";
            this.员工奖惩管理ToolStripMenuItem.Click += new System.EventHandler(this.员工奖惩管理ToolStripMenuItem_Click);
            // 
            // 人员调动管理ToolStripMenuItem
            // 
            this.人员调动管理ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.人员调动管理ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.人员调动管理ToolStripMenuItem.Name = "人员调动管理ToolStripMenuItem";
            this.人员调动管理ToolStripMenuItem.Size = new System.Drawing.Size(200, 30);
            this.人员调动管理ToolStripMenuItem.Text = "人员调动管理";
            // 
            // 劳保福利发放ToolStripMenuItem
            // 
            this.劳保福利发放ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.劳保福利发放ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.劳保福利发放ToolStripMenuItem.Name = "劳保福利发放ToolStripMenuItem";
            this.劳保福利发放ToolStripMenuItem.Size = new System.Drawing.Size(200, 30);
            this.劳保福利发放ToolStripMenuItem.Text = "劳保福利发放";
            // 
            // 人员考评管理ToolStripMenuItem
            // 
            this.人员考评管理ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.人员考评管理ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.人员考评管理ToolStripMenuItem.Name = "人员考评管理ToolStripMenuItem";
            this.人员考评管理ToolStripMenuItem.Size = new System.Drawing.Size(200, 30);
            this.人员考评管理ToolStripMenuItem.Text = "人员考评管理";
            // 
            // 人员信息统计ToolStripMenuItem
            // 
            this.人员信息统计ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.人员信息统计ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.人员信息统计ToolStripMenuItem.Name = "人员信息统计ToolStripMenuItem";
            this.人员信息统计ToolStripMenuItem.Size = new System.Drawing.Size(200, 30);
            this.人员信息统计ToolStripMenuItem.Text = "人员信息统计";
            // 
            // 部门管理ToolStripMenuItem
            // 
            this.部门管理ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuText;
            this.部门管理ToolStripMenuItem.Name = "部门管理ToolStripMenuItem";
            this.部门管理ToolStripMenuItem.Size = new System.Drawing.Size(94, 28);
            this.部门管理ToolStripMenuItem.Text = "部门管理";
            this.部门管理ToolStripMenuItem.Click += new System.EventHandler(this.部门管理ToolStripMenuItem_Click);
            // 
            // 用户管理ToolStripMenuItem
            // 
            this.用户管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改密码ToolStripMenuItem,
            this.添加用户ToolStripMenuItem});
            this.用户管理ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuText;
            this.用户管理ToolStripMenuItem.Name = "用户管理ToolStripMenuItem";
            this.用户管理ToolStripMenuItem.Size = new System.Drawing.Size(94, 28);
            this.用户管理ToolStripMenuItem.Text = "用户管理";
            // 
            // 修改密码ToolStripMenuItem
            // 
            this.修改密码ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.修改密码ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem";
            this.修改密码ToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.修改密码ToolStripMenuItem.Text = "修改密码";
            // 
            // 添加用户ToolStripMenuItem
            // 
            this.添加用户ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.添加用户ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.添加用户ToolStripMenuItem.Name = "添加用户ToolStripMenuItem";
            this.添加用户ToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.添加用户ToolStripMenuItem.Text = "添加用户";
            this.添加用户ToolStripMenuItem.Click += new System.EventHandler(this.添加用户ToolStripMenuItem_Click);
            // 
            // 设置ToolStripMenuItem
            // 
            this.设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.皮肤修改ToolStripMenuItem});
            this.设置ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuText;
            this.设置ToolStripMenuItem.Name = "设置ToolStripMenuItem";
            this.设置ToolStripMenuItem.Size = new System.Drawing.Size(58, 28);
            this.设置ToolStripMenuItem.Text = "设置";
            // 
            // 皮肤修改ToolStripMenuItem
            // 
            this.皮肤修改ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.皮肤修改ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.皮肤修改ToolStripMenuItem.Name = "皮肤修改ToolStripMenuItem";
            this.皮肤修改ToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.皮肤修改ToolStripMenuItem.Text = "皮肤修改";
            this.皮肤修改ToolStripMenuItem.Click += new System.EventHandler(this.皮肤修改ToolStripMenuItem_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.帮助文档ToolStripMenuItem});
            this.帮助ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.MenuText;
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(58, 28);
            this.帮助ToolStripMenuItem.Text = "帮助";
            // 
            // 帮助文档ToolStripMenuItem
            // 
            this.帮助文档ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.帮助文档ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.帮助文档ToolStripMenuItem.Name = "帮助文档ToolStripMenuItem";
            this.帮助文档ToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.帮助文档ToolStripMenuItem.Text = "帮助文档";
            this.帮助文档ToolStripMenuItem.Click += new System.EventHandler(this.帮助文档ToolStripMenuItem_Click);
            // 
            // 系统退出ToolStripMenuItem
            // 
            this.系统退出ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.退出ToolStripMenuItem,
            this.重新登录ToolStripMenuItem});
            this.系统退出ToolStripMenuItem.Name = "系统退出ToolStripMenuItem";
            this.系统退出ToolStripMenuItem.Size = new System.Drawing.Size(94, 28);
            this.系统退出ToolStripMenuItem.Text = "系统退出";
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.退出ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // 重新登录ToolStripMenuItem
            // 
            this.重新登录ToolStripMenuItem.BackColor = System.Drawing.SystemColors.HotTrack;
            this.重新登录ToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Window;
            this.重新登录ToolStripMenuItem.Name = "重新登录ToolStripMenuItem";
            this.重新登录ToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.重新登录ToolStripMenuItem.Text = "重新登录";
            this.重新登录ToolStripMenuItem.Click += new System.EventHandler(this.重新登录ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.btnDepartment);
            this.panel1.Controls.Add(this.btnHrManage);
            this.panel1.Controls.Add(this.btnUserManage);
            this.panel1.Location = new System.Drawing.Point(0, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 516);
            this.panel1.TabIndex = 1;
            // 
            // btnDepartment
            // 
            this.btnDepartment.Location = new System.Drawing.Point(47, 253);
            this.btnDepartment.Name = "btnDepartment";
            this.btnDepartment.Size = new System.Drawing.Size(101, 36);
            this.btnDepartment.TabIndex = 2;
            this.btnDepartment.Text = "部门管理";
            this.btnDepartment.UseVisualStyleBackColor = true;
            this.btnDepartment.Click += new System.EventHandler(this.btnDepartment_Click);
            // 
            // btnHrManage
            // 
            this.btnHrManage.Location = new System.Drawing.Point(47, 40);
            this.btnHrManage.Name = "btnHrManage";
            this.btnHrManage.Size = new System.Drawing.Size(101, 36);
            this.btnHrManage.TabIndex = 0;
            this.btnHrManage.Text = "人事管理";
            this.btnHrManage.UseVisualStyleBackColor = true;
            this.btnHrManage.Click += new System.EventHandler(this.btnHrManage_Click);
            // 
            // btnUserManage
            // 
            this.btnUserManage.Location = new System.Drawing.Point(47, 140);
            this.btnUserManage.Name = "btnUserManage";
            this.btnUserManage.Size = new System.Drawing.Size(101, 36);
            this.btnUserManage.TabIndex = 1;
            this.btnUserManage.Text = "用户管理";
            this.btnUserManage.UseVisualStyleBackColor = true;
            this.btnUserManage.Click += new System.EventHandler(this.btnUserManage_Click);
            // 
            // plHR
            // 
            this.plHR.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.plHR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.plHR.Controls.Add(this.btnRyxx);
            this.plHR.Controls.Add(this.pictureBox7);
            this.plHR.Controls.Add(this.btnRydd);
            this.plHR.Controls.Add(this.pictureBox6);
            this.plHR.Controls.Add(this.btnFyff);
            this.plHR.Controls.Add(this.pictureBox5);
            this.plHR.Controls.Add(this.btnYgpx);
            this.plHR.Controls.Add(this.pictureBox4);
            this.plHR.Controls.Add(this.btnRykp);
            this.plHR.Controls.Add(this.pictureBox3);
            this.plHR.Controls.Add(this.btnJC);
            this.plHR.Controls.Add(this.pictureBox2);
            this.plHR.Controls.Add(this.btnFile);
            this.plHR.Controls.Add(this.pictureBox1);
            this.plHR.Font = new System.Drawing.Font("宋体", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.plHR.Location = new System.Drawing.Point(200, 36);
            this.plHR.Name = "plHR";
            this.plHR.Size = new System.Drawing.Size(627, 515);
            this.plHR.TabIndex = 2;
            // 
            // btnRyxx
            // 
            this.btnRyxx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRyxx.FlatAppearance.BorderSize = 0;
            this.btnRyxx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRyxx.Location = new System.Drawing.Point(63, 458);
            this.btnRyxx.Name = "btnRyxx";
            this.btnRyxx.Size = new System.Drawing.Size(140, 47);
            this.btnRyxx.TabIndex = 13;
            this.btnRyxx.Text = "人员信息统计";
            this.btnRyxx.UseVisualStyleBackColor = false;
            this.btnRyxx.Click += new System.EventHandler(this.btnRyxx_Click);
            // 
            // btnRydd
            // 
            this.btnRydd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRydd.FlatAppearance.BorderSize = 0;
            this.btnRydd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRydd.Location = new System.Drawing.Point(325, 338);
            this.btnRydd.Name = "btnRydd";
            this.btnRydd.Size = new System.Drawing.Size(140, 47);
            this.btnRydd.TabIndex = 11;
            this.btnRydd.Text = "人员调动管理";
            this.btnRydd.UseVisualStyleBackColor = false;
            this.btnRydd.Click += new System.EventHandler(this.btnRydd_Click);
            // 
            // btnFyff
            // 
            this.btnFyff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFyff.FlatAppearance.BorderSize = 0;
            this.btnFyff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFyff.Location = new System.Drawing.Point(65, 338);
            this.btnFyff.Name = "btnFyff";
            this.btnFyff.Size = new System.Drawing.Size(140, 47);
            this.btnFyff.TabIndex = 9;
            this.btnFyff.Text = "福利发放管理";
            this.btnFyff.UseVisualStyleBackColor = false;
            this.btnFyff.Click += new System.EventHandler(this.btnFyff_Click);
            // 
            // btnYgpx
            // 
            this.btnYgpx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnYgpx.FlatAppearance.BorderSize = 0;
            this.btnYgpx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYgpx.Location = new System.Drawing.Point(335, 209);
            this.btnYgpx.Name = "btnYgpx";
            this.btnYgpx.Size = new System.Drawing.Size(140, 47);
            this.btnYgpx.TabIndex = 7;
            this.btnYgpx.Text = "员工培训管理";
            this.btnYgpx.UseVisualStyleBackColor = false;
            this.btnYgpx.Click += new System.EventHandler(this.btnYgpx_Click);
            // 
            // btnRykp
            // 
            this.btnRykp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRykp.FlatAppearance.BorderSize = 0;
            this.btnRykp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRykp.Location = new System.Drawing.Point(65, 212);
            this.btnRykp.Name = "btnRykp";
            this.btnRykp.Size = new System.Drawing.Size(140, 47);
            this.btnRykp.TabIndex = 5;
            this.btnRykp.Text = "人员考评管理";
            this.btnRykp.UseVisualStyleBackColor = false;
            this.btnRykp.Click += new System.EventHandler(this.btnRykp_Click);
            // 
            // btnJC
            // 
            this.btnJC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnJC.FlatAppearance.BorderSize = 0;
            this.btnJC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnJC.Location = new System.Drawing.Point(335, 83);
            this.btnJC.Name = "btnJC";
            this.btnJC.Size = new System.Drawing.Size(140, 47);
            this.btnJC.TabIndex = 3;
            this.btnJC.Text = "人员奖惩管理";
            this.btnJC.UseVisualStyleBackColor = false;
            this.btnJC.Click += new System.EventHandler(this.btnJC_Click);
            // 
            // btnFile
            // 
            this.btnFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFile.FlatAppearance.BorderSize = 0;
            this.btnFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFile.Location = new System.Drawing.Point(65, 89);
            this.btnFile.Name = "btnFile";
            this.btnFile.Size = new System.Drawing.Size(140, 47);
            this.btnFile.TabIndex = 1;
            this.btnFile.Text = "员工档案管理";
            this.btnFile.UseVisualStyleBackColor = false;
            this.btnFile.Click += new System.EventHandler(this.btnFile_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.pictureBox9);
            this.panel2.Controls.Add(this.btnUserAdd);
            this.panel2.Controls.Add(this.pictureBox8);
            this.panel2.Controls.Add(this.btnPwdEdit);
            this.panel2.Location = new System.Drawing.Point(200, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(622, 506);
            this.panel2.TabIndex = 14;
            // 
            // btnUserAdd
            // 
            this.btnUserAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnUserAdd.FlatAppearance.BorderSize = 0;
            this.btnUserAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUserAdd.Font = new System.Drawing.Font("宋体", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnUserAdd.Location = new System.Drawing.Point(300, 172);
            this.btnUserAdd.Name = "btnUserAdd";
            this.btnUserAdd.Size = new System.Drawing.Size(133, 32);
            this.btnUserAdd.TabIndex = 15;
            this.btnUserAdd.Text = "用户管理";
            this.btnUserAdd.UseVisualStyleBackColor = false;
            this.btnUserAdd.Click += new System.EventHandler(this.btnUserAdd_Click);
            // 
            // btnPwdEdit
            // 
            this.btnPwdEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPwdEdit.FlatAppearance.BorderSize = 0;
            this.btnPwdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPwdEdit.Font = new System.Drawing.Font("宋体", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnPwdEdit.Location = new System.Drawing.Point(72, 163);
            this.btnPwdEdit.Name = "btnPwdEdit";
            this.btnPwdEdit.Size = new System.Drawing.Size(133, 32);
            this.btnPwdEdit.TabIndex = 13;
            this.btnPwdEdit.Text = "修改密码";
            this.btnPwdEdit.UseVisualStyleBackColor = false;
            this.btnPwdEdit.Click += new System.EventHandler(this.btnPwdEdit_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Controls.Add(this.btnDepart);
            this.panel3.Controls.Add(this.pictureBox10);
            this.panel3.Location = new System.Drawing.Point(200, 35);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(627, 513);
            this.panel3.TabIndex = 15;
            // 
            // btnDepart
            // 
            this.btnDepart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDepart.FlatAppearance.BorderSize = 0;
            this.btnDepart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDepart.Font = new System.Drawing.Font("宋体", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnDepart.Location = new System.Drawing.Point(70, 142);
            this.btnDepart.Name = "btnDepart";
            this.btnDepart.Size = new System.Drawing.Size(133, 32);
            this.btnDepart.TabIndex = 17;
            this.btnDepart.Text = "部门管理";
            this.btnDepart.UseVisualStyleBackColor = false;
            this.btnDepart.Click += new System.EventHandler(this.btnDepart_Click);
            // 
            // skinEngine1
            // 
            this.skinEngine1.SerialNumber = "";
            this.skinEngine1.SkinDialogs = false;
            this.skinEngine1.SkinFile = null;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::HRMS.Properties.Resources.修改密码;
            this.pictureBox9.Location = new System.Drawing.Point(101, 80);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(70, 70);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 12;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::HRMS.Properties.Resources.员工档案管理;
            this.pictureBox8.Location = new System.Drawing.Point(335, 80);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(70, 70);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 14;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::HRMS.Properties.Resources.人员信息统计;
            this.pictureBox7.Location = new System.Drawing.Point(96, 394);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(70, 70);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::HRMS.Properties.Resources.人员调动管理;
            this.pictureBox6.Location = new System.Drawing.Point(363, 267);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(70, 70);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::HRMS.Properties.Resources.福利发放管理;
            this.pictureBox5.Location = new System.Drawing.Point(98, 272);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(70, 70);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Image = global::HRMS.Properties.Resources.员工培训管理;
            this.pictureBox4.Location = new System.Drawing.Point(363, 140);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(70, 70);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::HRMS.Properties.Resources.人员考评管理;
            this.pictureBox3.Location = new System.Drawing.Point(94, 144);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(70, 70);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::HRMS.Properties.Resources.人员奖惩管理;
            this.pictureBox2.Location = new System.Drawing.Point(363, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(70, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::HRMS.Properties.Resources.员工档案管理;
            this.pictureBox1.Location = new System.Drawing.Point(98, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::HRMS.Properties.Resources.员工档案管理;
            this.pictureBox10.Location = new System.Drawing.Point(101, 64);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(70, 70);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 16;
            this.pictureBox10.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 549);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.plHR);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "主页面";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.plHR.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 人事管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 部门管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 用户管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 皮肤修改ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 员工档案管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 员工培训管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 员工奖惩管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人员调动管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 劳保福利发放ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人员考评管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人员信息统计ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDepartment;
        private System.Windows.Forms.Button btnUserManage;
        private System.Windows.Forms.Button btnHrManage;
        private System.Windows.Forms.Panel plHR;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnFile;
        private System.Windows.Forms.Button btnYgpx;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btnRykp;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnJC;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnRyxx;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button btnRydd;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btnFyff;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnUserAdd;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button btnPwdEdit;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnDepart;
        private System.Windows.Forms.PictureBox pictureBox10;
        private Sunisoft.IrisSkin.SkinEngine skinEngine1;
        private System.Windows.Forms.ToolStripMenuItem 系统退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 重新登录ToolStripMenuItem;
    }
}