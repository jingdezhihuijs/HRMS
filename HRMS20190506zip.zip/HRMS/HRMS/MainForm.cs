﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class MainForm : Form
    {
        SkinSet skinset = new SkinSet();
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 人事管理button事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnHrManage_Click(object sender, EventArgs e)
        {
            this.plHR.Visible = true;
            this.panel2.Visible = false;
            this.panel3.Visible = false;
        }

        /// <summary>
        /// 用户管理button事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUserManage_Click(object sender, EventArgs e)
        {
            this.plHR.Visible = false;
            this.panel2.Visible = true;
            this.panel3.Visible = false;
        }

        /// <summary>
        /// 部门管理button事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDepartment_Click(object sender, EventArgs e)
        {
            this.plHR.Hide();
            this.panel2.Hide();
            this.panel3.Show();
        }

        /// <summary>
        /// 员工档案管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFile_Click(object sender, EventArgs e)
        {
            new StaffRecordsForm().Show();
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPwdEdit_Click(object sender, EventArgs e)
        {
            new PasswordEditForm().Show();
        }

        /// <summary>
        /// 用户添加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUserAdd_Click(object sender, EventArgs e)
        {
            new UserManageForm().Show();
        }

        /// <summary>
        /// 人员奖惩管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnJC_Click(object sender, EventArgs e)
        {
            new RyjcManageForm().Show();
        }

        /// <summary>
        /// 人员考评
        /// </summary
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRykp_Click(object sender, EventArgs e)
        {
            new RykpManageForm().Show();
        }

        /// <summary>
        /// 员工培训
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnYgpx_Click(object sender, EventArgs e)
        {
            new YgpxManageForm().Show();
        }

        /// <summary>
        /// 福利发放管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFyff_Click(object sender, EventArgs e)
        {
            new FlffManageForm().ShowDialog();
        }

        /// <summary>
        /// 人员调动管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRydd_Click(object sender, EventArgs e)
        {
            new RyddManageForm().Show();
        }

        /// <summary>
        /// 人员信息统计
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRyxx_Click(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// 部门管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDepart_Click(object sender, EventArgs e)
        {
            new DepartManagerForm().ShowDialog();
        }

        #region
        /// <summary>
        /// 员工培训管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 员工培训管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new YgpxManageForm().Show();
        }

        /// <summary>
        /// 员工奖惩管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 员工奖惩管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new RyjcManageForm().Show();
        }
       
        /// <summary>
        /// 部门管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 部门管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new DepartManagerForm().ShowDialog();
        }
       
        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 添加用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new UserManageForm().Show();
        }
        #endregion

        /// <summary>
        /// 皮肤修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 皮肤修改ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new SkinForm().ShowDialog();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //判断皮肤
            CheckSkill();
        }

        //加载不同的皮肤
        void CheckSkill()
        {
            DataTable dt = skinset.SelectPifu();
            if (dt.Rows.Count > 0)
            {
                string pf = dt.Rows[0][1].ToString();
                if (pf == "Mac系统")
                {
                    this.skinEngine1.SkinFile = "skin\\MacOS.ssk";
                }
                else if (pf == "钻石蓝")
                {
                    this.skinEngine1.SkinFile = "skin\\DiamondBlue.ssk";
                }
                else if (pf == "简约灰")
                {
                    this.skinEngine1.SkinFile = "skin\\Longhorn.ssk";
                }
                else if (pf == "俊朗黑")
                {
                    this.skinEngine1.SkinFile = "skin\\CalmnessColor1.ssk";
                }
                else if (pf == "深沉绿")
                {
                    this.skinEngine1.SkinFile = "skin\\MidsummerColor1.ssk";
                }
                else if (pf == "温馨橙")
                {
                    this.skinEngine1.SkinFile = "skin\\WarmColor1.ssk";
                }
                else if (pf == "默认")
                {
                    //this.skinEngine1.SkinFile = "skin\\WarmColor1.ssk";
                }
            }
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("您确定要退出系统吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
                //System.Diagnostics.Process.Start("FixedAssets.exe");
                Application.Exit();
            }
        }

        /// <summary>
        /// 重新登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 重新登录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定要重新登录系统吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Restart();
            }
        }

        /// <summary>
        /// 帮助文档
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 帮助文档ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new HelpForm().Show();
        }
    }
}
