﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class PasswordEditForm : Form
    {
        UserHelper userHelper = new UserHelper();
        string userId = "";
        public PasswordEditForm()
        {
            InitializeComponent();
        }

        public PasswordEditForm(string id, string editType)
        {
            InitializeComponent();

            userId = id;
            DataTable dt = userHelper.GetUserInfoById(userId);
            if (dt.Rows.Count > 0)
            {
                txtName.Text = dt.Rows[0]["UserName"].ToString();
            }
            else
            {
                MessageBox.Show("数据加载失败！");
            }
        }

        /// <summary>
        /// 确定保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text.ToString().Trim() == "")
            {
                MessageBox.Show("员工信息不能为空！");
                return;
            }
            if (txtNewPwd.Text.ToString().Trim() == "")
            {
                MessageBox.Show("请输入密码！");
                return;
            }
            if (txtPwdC.Text.ToString().Trim() == "")
            {
                MessageBox.Show("请输入确认密码！");
                return;
            }
            if (txtNewPwd.Text.ToString() != txtPwdC.Text.ToString())
            {
                MessageBox.Show("两次密码输入值不同，请重新输入");
                return;
            }

            DataTable dt_User = userHelper.GetUserInfoById(userId);

            //编辑数据
            if (dt_User.Rows.Count > 0)
            {
                dt_User.Rows[0]["Password"] = txtNewPwd.Text.ToString();
                userHelper.EditUserInfo(dt_User);
                MessageBox.Show("用户密码成功！");
                this.Close();
            }
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtNewPwd.Text = "";
            txtPwdC.Text   = "";
        }
    }
}
