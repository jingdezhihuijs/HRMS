﻿namespace HRMS
{
    partial class RyddAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RyddAddForm));
            this.txtOldJob = new System.Windows.Forms.TextBox();
            this.cmbNewJob = new System.Windows.Forms.ComboBox();
            this.cmbNewDept = new System.Windows.Forms.ComboBox();
            this.cmbUserCode = new System.Windows.Forms.ComboBox();
            this.txtOldDept = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.llbExit = new System.Windows.Forms.LinkLabel();
            this.llbSave = new System.Windows.Forms.LinkLabel();
            this.llbAdd = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtOldJob
            // 
            this.txtOldJob.Enabled = false;
            this.txtOldJob.Location = new System.Drawing.Point(154, 255);
            this.txtOldJob.Margin = new System.Windows.Forms.Padding(4);
            this.txtOldJob.Name = "txtOldJob";
            this.txtOldJob.Size = new System.Drawing.Size(148, 28);
            this.txtOldJob.TabIndex = 11;
            // 
            // cmbNewJob
            // 
            this.cmbNewJob.FormattingEnabled = true;
            this.cmbNewJob.Location = new System.Drawing.Point(610, 259);
            this.cmbNewJob.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNewJob.Name = "cmbNewJob";
            this.cmbNewJob.Size = new System.Drawing.Size(180, 26);
            this.cmbNewJob.TabIndex = 10;
            // 
            // cmbNewDept
            // 
            this.cmbNewDept.FormattingEnabled = true;
            this.cmbNewDept.Location = new System.Drawing.Point(610, 155);
            this.cmbNewDept.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNewDept.Name = "cmbNewDept";
            this.cmbNewDept.Size = new System.Drawing.Size(180, 26);
            this.cmbNewDept.TabIndex = 9;
            // 
            // cmbUserCode
            // 
            this.cmbUserCode.FormattingEnabled = true;
            this.cmbUserCode.Location = new System.Drawing.Point(154, 65);
            this.cmbUserCode.Margin = new System.Windows.Forms.Padding(4);
            this.cmbUserCode.Name = "cmbUserCode";
            this.cmbUserCode.Size = new System.Drawing.Size(180, 26);
            this.cmbUserCode.TabIndex = 8;
            this.cmbUserCode.SelectedIndexChanged += new System.EventHandler(this.cmbUserCode_SelectedIndexChanged);
            // 
            // txtOldDept
            // 
            this.txtOldDept.Enabled = false;
            this.txtOldDept.Location = new System.Drawing.Point(154, 159);
            this.txtOldDept.Margin = new System.Windows.Forms.Padding(4);
            this.txtOldDept.Name = "txtOldDept";
            this.txtOldDept.Size = new System.Drawing.Size(148, 28);
            this.txtOldDept.TabIndex = 7;
            // 
            // txtUsername
            // 
            this.txtUsername.Enabled = false;
            this.txtUsername.Location = new System.Drawing.Point(614, 63);
            this.txtUsername.Margin = new System.Windows.Forms.Padding(4);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(148, 28);
            this.txtUsername.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(519, 267);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "新职务：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(66, 267);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "原职务：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(522, 167);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "新部门：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 167);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "原部门：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(508, 69);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "员工姓名：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 69);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "员工编号：";
            // 
            // llbExit
            // 
            this.llbExit.AutoSize = true;
            this.llbExit.Location = new System.Drawing.Point(151, 17);
            this.llbExit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbExit.Name = "llbExit";
            this.llbExit.Size = new System.Drawing.Size(44, 18);
            this.llbExit.TabIndex = 2;
            this.llbExit.TabStop = true;
            this.llbExit.Text = "退出";
            this.llbExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbExit_LinkClicked);
            // 
            // llbSave
            // 
            this.llbSave.AutoSize = true;
            this.llbSave.Location = new System.Drawing.Point(81, 17);
            this.llbSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbSave.Name = "llbSave";
            this.llbSave.Size = new System.Drawing.Size(44, 18);
            this.llbSave.TabIndex = 1;
            this.llbSave.TabStop = true;
            this.llbSave.Text = "保存";
            this.llbSave.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbSave_LinkClicked);
            // 
            // llbAdd
            // 
            this.llbAdd.AutoSize = true;
            this.llbAdd.Location = new System.Drawing.Point(15, 17);
            this.llbAdd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbAdd.Name = "llbAdd";
            this.llbAdd.Size = new System.Drawing.Size(44, 18);
            this.llbAdd.TabIndex = 0;
            this.llbAdd.TabStop = true;
            this.llbAdd.Text = "增加";
            this.llbAdd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbAdd_LinkClicked);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtOldJob);
            this.groupBox1.Controls.Add(this.cmbNewJob);
            this.groupBox1.Controls.Add(this.cmbNewDept);
            this.groupBox1.Controls.Add(this.cmbUserCode);
            this.groupBox1.Controls.Add(this.txtOldDept);
            this.groupBox1.Controls.Add(this.txtUsername);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(43, 71);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(848, 346);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "调度部门信息";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.llbExit);
            this.panel1.Controls.Add(this.llbSave);
            this.panel1.Controls.Add(this.llbAdd);
            this.panel1.Location = new System.Drawing.Point(43, 3);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(848, 46);
            this.panel1.TabIndex = 2;
            // 
            // RyddAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 443);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RyddAddForm";
            this.Text = "增加人员调度";
            this.Load += new System.EventHandler(this.RyddAddForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtOldJob;
        private System.Windows.Forms.ComboBox cmbNewJob;
        private System.Windows.Forms.ComboBox cmbNewDept;
        private System.Windows.Forms.ComboBox cmbUserCode;
        private System.Windows.Forms.TextBox txtOldDept;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel llbExit;
        private System.Windows.Forms.LinkLabel llbSave;
        private System.Windows.Forms.LinkLabel llbAdd;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
    }
}