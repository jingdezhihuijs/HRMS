﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class RyddAddForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        UserHelper userHelper = new UserHelper();
        string dd_id = "";
        public RyddAddForm()
        {
            InitializeComponent();
        }

        public RyddAddForm(string id, string editType)
        {
            InitializeComponent();
            dd_id = id;
            DataTable dt = commonHelper.GetRyddInfoByID(id);
            if (dt.Rows.Count > 0)
            {
                cmbUserCode.SelectedValue = dt.Rows[0]["User_id"].ToString();
                txtUsername.Text = dt.Rows[0]["name"].ToString();
                txtOldDept.Text = dt.Rows[0]["Old_depart"].ToString();
                txtOldJob.Text = dt.Rows[0]["Old_job"].ToString();
                cmbNewDept.Text = dt.Rows[0]["New_depart"].ToString();
                cmbNewJob.Text = dt.Rows[0]["New_job"].ToString();

            }
            else
            {
                MessageBox.Show("数据加载失败！");
            }

            if (editType == "View")
            {
                cmbUserCode.Enabled = false;
                cmbNewDept.Enabled = false;
                cmbNewJob.Enabled = false;
                llbAdd.Enabled = false;
                llbSave.Enabled = false;
            }
        }

        /// <summary>
        /// 增加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string userCode = this.cmbUserCode.SelectedValue.ToString();
            string name = this.txtUsername.Text.ToString();
            string oldDept = this.txtOldDept.Text.ToString();
            string oldJob = this.txtOldJob.Text.ToString();
            string newDept = this.cmbNewDept.Text.ToString();
            string newJob = this.cmbNewJob.Text.ToString();
            //考评结果

            try
            {
                DataTable dt_UserInfo = userHelper.GetUserInfoById(userCode);

                dt_UserInfo.Rows[0]["Job_id"] = this.cmbNewJob.SelectedValue.ToString(); ;
                dt_UserInfo.Rows[0]["DepartId"] = this.cmbNewDept.SelectedValue.ToString();
                userHelper.EditUserInfo(dt_UserInfo);
            }
            catch 
            {
                MessageBox.Show("用户信息更新失败");
                return;
            }
            
            DataTable dt_RyddInfo = commonHelper.GetRyddInfoList("");
            //添加记录
            DataRow Nrow = dt_RyddInfo.NewRow();
            Nrow["User_id"] = userCode.Trim();
            Nrow["Old_depart"] = oldDept.Trim();
            Nrow["New_depart"] = newDept;
            Nrow["Old_job"] = oldJob;
            Nrow["New_job"] = newJob;
            Nrow["datetime"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            Nrow["name"] = name;
            dt_RyddInfo.Rows.Add(Nrow);
            commonHelper.AddInfo(dt_RyddInfo);
            MessageBox.Show("数据添加成功！");
            this.Close();
        }

        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbSave_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string userCode = this.cmbUserCode.SelectedValue.ToString();
            string name = this.txtUsername.Text.ToString();
            string oldDept = this.txtOldDept.Text.ToString();
            string oldJob = this.txtOldJob.Text.ToString();
            string newDept = this.cmbNewDept.Text.ToString();
            string newJob = this.cmbNewJob.Text.ToString();

            try
            {
                DataTable dt_UserInfo = userHelper.GetUserInfoById(userCode);

                dt_UserInfo.Rows[0]["Job_id"] = this.cmbNewJob.SelectedValue.ToString(); ;
                dt_UserInfo.Rows[0]["DepartId"] = this.cmbNewDept.SelectedValue.ToString();
                userHelper.EditUserInfo(dt_UserInfo);
            }
            catch
            {
                MessageBox.Show("用户信息更新失败");
                return;
            }

            DataTable dt_RyddInfo = commonHelper.GetRyddInfoByID(dd_id);

            dt_RyddInfo.Rows[0]["User_id"] = userCode.Trim();
            dt_RyddInfo.Rows[0]["Old_depart"] = oldDept.Trim();
            dt_RyddInfo.Rows[0]["New_depart"] = newDept;
            dt_RyddInfo.Rows[0]["Old_job"] = oldJob;
            dt_RyddInfo.Rows[0]["New_job"] = newJob;
            dt_RyddInfo.Rows[0]["datetime"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            dt_RyddInfo.Rows[0]["name"] = newDept;
            commonHelper.EditInfo(dt_RyddInfo);
            MessageBox.Show("数据保存成功！");
            this.Close();
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 信息加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RyddAddForm_Load(object sender, EventArgs e)
        {
            DataTable dt = commonHelper.GetUsersDetail();
            if (dt.Rows.Count > 0)
            {
                cmbUserCode.DisplayMember = "CodeName";
                cmbUserCode.ValueMember = "id";
                cmbUserCode.DataSource = dt;
                cmbUserCode.SelectedIndex = 0;
            }

            DataTable dtDepartment = commonHelper.GetDepartment();
            if (dtDepartment.Rows.Count > 0)
            {
                cmbNewDept.DisplayMember = "Depart_name";
                cmbNewDept.ValueMember = "id";
                cmbNewDept.DataSource = dtDepartment;
                cmbNewDept.SelectedIndex = 0;
            }

            DataTable dtJob = commonHelper.GetJobInfo();
            if (dtDepartment.Rows.Count > 0)
            {
                cmbNewJob.DisplayMember = "Dict_name";
                cmbNewJob.ValueMember = "id";
                cmbNewJob.DataSource = dtJob;
                cmbNewJob.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// 员工编号选择改变事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbUserCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)cmbUserCode.DataSource;
            txtUsername.Text = dt.Rows[cmbUserCode.SelectedIndex]["Name"].ToString();
            txtOldDept.Text = dt.Rows[cmbUserCode.SelectedIndex]["Depart_name"].ToString();
            txtOldJob.Text = dt.Rows[cmbUserCode.SelectedIndex]["jobName"].ToString();
        }
    }
}
