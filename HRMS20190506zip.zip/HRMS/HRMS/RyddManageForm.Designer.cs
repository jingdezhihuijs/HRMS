﻿namespace HRMS
{
    partial class RyddManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RyddManageForm));
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.llbExit = new System.Windows.Forms.LinkLabel();
            this.llbRefresh = new System.Windows.Forms.LinkLabel();
            this.llbView = new System.Windows.Forms.LinkLabel();
            this.llbDelete = new System.Windows.Forms.LinkLabel();
            this.llbAdd = new System.Windows.Forms.LinkLabel();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpBegin = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.llbSearch = new System.Windows.Forms.LinkLabel();
            this.dgvRydd = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rownum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.user_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Old_depart = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.New_depart = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Old_job = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.New_job = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datetime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRydd)).BeginInit();
            this.SuspendLayout();
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.Location = new System.Drawing.Point(297, 18);
            this.linkLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(44, 18);
            this.linkLabel6.TabIndex = 16;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "皮肤";
            // 
            // llbExit
            // 
            this.llbExit.AutoSize = true;
            this.llbExit.Location = new System.Drawing.Point(240, 18);
            this.llbExit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbExit.Name = "llbExit";
            this.llbExit.Size = new System.Drawing.Size(44, 18);
            this.llbExit.TabIndex = 15;
            this.llbExit.TabStop = true;
            this.llbExit.Text = "退出";
            this.llbExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbExit_LinkClicked);
            // 
            // llbRefresh
            // 
            this.llbRefresh.AutoSize = true;
            this.llbRefresh.Location = new System.Drawing.Point(188, 18);
            this.llbRefresh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbRefresh.Name = "llbRefresh";
            this.llbRefresh.Size = new System.Drawing.Size(44, 18);
            this.llbRefresh.TabIndex = 14;
            this.llbRefresh.TabStop = true;
            this.llbRefresh.Text = "刷新";
            this.llbRefresh.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbRefresh_LinkClicked);
            // 
            // llbView
            // 
            this.llbView.AutoSize = true;
            this.llbView.Location = new System.Drawing.Point(135, 18);
            this.llbView.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbView.Name = "llbView";
            this.llbView.Size = new System.Drawing.Size(44, 18);
            this.llbView.TabIndex = 13;
            this.llbView.TabStop = true;
            this.llbView.Text = "查找";
            this.llbView.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbView_LinkClicked);
            // 
            // llbDelete
            // 
            this.llbDelete.AutoSize = true;
            this.llbDelete.Location = new System.Drawing.Point(82, 16);
            this.llbDelete.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbDelete.Name = "llbDelete";
            this.llbDelete.Size = new System.Drawing.Size(44, 18);
            this.llbDelete.TabIndex = 12;
            this.llbDelete.TabStop = true;
            this.llbDelete.Text = "删除";
            this.llbDelete.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbDelete_LinkClicked);
            // 
            // llbAdd
            // 
            this.llbAdd.AutoSize = true;
            this.llbAdd.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.llbAdd.Location = new System.Drawing.Point(30, 18);
            this.llbAdd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbAdd.Name = "llbAdd";
            this.llbAdd.Size = new System.Drawing.Size(44, 18);
            this.llbAdd.TabIndex = 11;
            this.llbAdd.TabStop = true;
            this.llbAdd.Text = "增加";
            this.llbAdd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // dtpEnd
            // 
            this.dtpEnd.Location = new System.Drawing.Point(776, 13);
            this.dtpEnd.Margin = new System.Windows.Forms.Padding(4);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(182, 28);
            this.dtpEnd.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(742, 18);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 18);
            this.label8.TabIndex = 9;
            this.label8.Text = "从";
            // 
            // dtpBegin
            // 
            this.dtpBegin.Location = new System.Drawing.Point(540, 11);
            this.dtpBegin.Margin = new System.Windows.Forms.Padding(4);
            this.dtpBegin.Name = "dtpBegin";
            this.dtpBegin.Size = new System.Drawing.Size(194, 28);
            this.dtpBegin.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(384, 20);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "人员调动事件从";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.llbSearch);
            this.panel1.Controls.Add(this.linkLabel6);
            this.panel1.Controls.Add(this.llbExit);
            this.panel1.Controls.Add(this.llbRefresh);
            this.panel1.Controls.Add(this.llbView);
            this.panel1.Controls.Add(this.llbDelete);
            this.panel1.Controls.Add(this.llbAdd);
            this.panel1.Controls.Add(this.dtpEnd);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.dtpBegin);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(3, 8);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1478, 52);
            this.panel1.TabIndex = 2;
            // 
            // llbSearch
            // 
            this.llbSearch.AutoSize = true;
            this.llbSearch.Location = new System.Drawing.Point(966, 18);
            this.llbSearch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbSearch.Name = "llbSearch";
            this.llbSearch.Size = new System.Drawing.Size(44, 18);
            this.llbSearch.TabIndex = 17;
            this.llbSearch.TabStop = true;
            this.llbSearch.Text = "查询";
            this.llbSearch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbSearch_LinkClicked);
            // 
            // dgvRydd
            // 
            this.dgvRydd.AllowUserToAddRows = false;
            this.dgvRydd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRydd.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.rownum,
            this.user_id,
            this.name,
            this.Old_depart,
            this.New_depart,
            this.Old_job,
            this.New_job,
            this.datetime});
            this.dgvRydd.Location = new System.Drawing.Point(3, 69);
            this.dgvRydd.Margin = new System.Windows.Forms.Padding(4);
            this.dgvRydd.Name = "dgvRydd";
            this.dgvRydd.ReadOnly = true;
            this.dgvRydd.RowTemplate.Height = 23;
            this.dgvRydd.Size = new System.Drawing.Size(1105, 581);
            this.dgvRydd.TabIndex = 3;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // rownum
            // 
            this.rownum.DataPropertyName = "ROWNUM";
            this.rownum.HeaderText = "编号";
            this.rownum.Name = "rownum";
            this.rownum.ReadOnly = true;
            // 
            // user_id
            // 
            this.user_id.DataPropertyName = "User_code";
            this.user_id.HeaderText = "员工编号";
            this.user_id.Name = "user_id";
            this.user_id.ReadOnly = true;
            // 
            // name
            // 
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "名称";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // Old_depart
            // 
            this.Old_depart.DataPropertyName = "Old_depart";
            this.Old_depart.HeaderText = "旧部门";
            this.Old_depart.Name = "Old_depart";
            this.Old_depart.ReadOnly = true;
            // 
            // New_depart
            // 
            this.New_depart.DataPropertyName = "New_depart";
            this.New_depart.HeaderText = "新部门";
            this.New_depart.Name = "New_depart";
            this.New_depart.ReadOnly = true;
            // 
            // Old_job
            // 
            this.Old_job.DataPropertyName = "Old_job";
            this.Old_job.HeaderText = "旧职务";
            this.Old_job.Name = "Old_job";
            this.Old_job.ReadOnly = true;
            // 
            // New_job
            // 
            this.New_job.DataPropertyName = "New_job";
            this.New_job.HeaderText = "新职务";
            this.New_job.Name = "New_job";
            this.New_job.ReadOnly = true;
            // 
            // datetime
            // 
            this.datetime.DataPropertyName = "datetime";
            this.datetime.HeaderText = "调动时间";
            this.datetime.Name = "datetime";
            this.datetime.ReadOnly = true;
            // 
            // RyddManageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1112, 654);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvRydd);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RyddManageForm";
            this.Text = "人员调动管理";
            this.Load += new System.EventHandler(this.RyddManageForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRydd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel llbExit;
        private System.Windows.Forms.LinkLabel llbRefresh;
        private System.Windows.Forms.LinkLabel llbView;
        private System.Windows.Forms.LinkLabel llbDelete;
        private System.Windows.Forms.LinkLabel llbAdd;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpBegin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvRydd;
        private System.Windows.Forms.LinkLabel llbSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn rownum;
        private System.Windows.Forms.DataGridViewTextBoxColumn user_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Old_depart;
        private System.Windows.Forms.DataGridViewTextBoxColumn New_depart;
        private System.Windows.Forms.DataGridViewTextBoxColumn Old_job;
        private System.Windows.Forms.DataGridViewTextBoxColumn New_job;
        private System.Windows.Forms.DataGridViewTextBoxColumn datetime;
    }
}