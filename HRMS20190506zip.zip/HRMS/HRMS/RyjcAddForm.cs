﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class RyjcAddForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        UserHelper userHelper = new UserHelper();
        string jc_id = "";
        string job_id = "";
        public RyjcAddForm()
        {
            InitializeComponent();
        }

        private void RyjcAddForm_Load(object sender, EventArgs e)
        {
            DataTable dt = commonHelper.GetUsers();
            if (dt.Rows.Count > 0)
            {
                cmbUserCode.DisplayMember = "User_code";
                cmbUserCode.ValueMember = "id";
                cmbUserCode.DataSource = dt;
                cmbUserCode.SelectedIndex = 0;
            }

            DataTable dtDepartment = commonHelper.GetDepartment();
            if (dtDepartment.Rows.Count > 0)
            {
                cmbDept.DisplayMember = "Depart_name";
                cmbDept.ValueMember = "id";
                cmbDept.DataSource = dtDepartment;
                cmbDept.SelectedIndex = 0;
            }
        }


        public RyjcAddForm(string id, string editType)
        {
            InitializeComponent();
            jc_id = id;
            DataTable dt = commonHelper.GetRyjcInfoByID(id);
            if (dt.Rows.Count > 0)
            {
                cmbUserCode.SelectedValue = dt.Rows[0]["User_id"].ToString();
                cmbDept.SelectedValue = dt.Rows[0]["Depart_id"].ToString();
                txtMoney.Text = dt.Rows[0]["Money"].ToString();
                cmbType.SelectedItem = dt.Rows[0]["Type"].ToString();
                txtReason.Text = dt.Rows[0]["Reason"].ToString();
                job_id = dt.Rows[0]["Job_id"].ToString();

            }
            else
            {
                MessageBox.Show("数据加载失败！");
            }

            if (editType == "View")
            {
                cmbUserCode.Enabled = false;
                cmbDept.Enabled = false;
                txtMoney.Enabled = false;
                cmbType.Enabled = false;
                txtReason.Enabled = false;
                tsbAdd.Enabled = false;
                tsbSave.Enabled = false;
            }
        }

        /// <summary>
        /// 用户编号选择改变事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbUserCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)cmbUserCode.DataSource;
            txtName.Text = dt.Rows[cmbUserCode.SelectedIndex]["Name"].ToString();
            cmbDept.SelectedValue = dt.Rows[cmbUserCode.SelectedIndex]["DepartId"].ToString();
            job_id = dt.Rows[cmbUserCode.SelectedIndex]["Job_id"].ToString();
            string userid = cmbUserCode.SelectedValue.ToString();
            DataTable dtKp = commonHelper.GetRykpInfoByUserId(userid);
            if (dtKp.Rows.Count > 0)
            {
                txtJcContent.Text = dtKp.Rows[0]["Kp_content"].ToString();
                txtKpResult.Text = dtKp.Rows[0]["Kp_result"].ToString();
                txtKpScore.Text = dtKp.Rows[0]["Score"].ToString();

            }
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbAdd_Click(object sender, EventArgs e)
        {
            string userCode = this.cmbUserCode.SelectedValue.ToString();
            string name = this.txtName.Text.ToString();
            string department = this.cmbDept.SelectedValue.ToString();
            //奖惩类型
            string rewardsType = this.cmbType.SelectedText.ToString();
            //奖罚原因
            string reason = this.txtReason.Text.ToString();
            //奖罚金额
            double money = double.Parse( this.txtMoney.Text);
            DataTable dt_RyjcInfo = commonHelper.GetRyjcInfoList("");
            //添加记录
            DataRow Nrow = dt_RyjcInfo.NewRow();
            Nrow["User_id"] = userCode.Trim();
            Nrow["Depart_id"] = department.Trim();
            Nrow["Job_id"] = job_id;
            Nrow["Type"] = rewardsType;
            Nrow["Reason"] = reason;
            Nrow["Money"] = money;
            Nrow["datetime"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            dt_RyjcInfo.Rows.Add(Nrow);
            commonHelper.AddInfo(dt_RyjcInfo);
            MessageBox.Show("数据添加成功！");
            this.Close();
        }

        /// <summary>
        /// 编辑保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbSave_Click(object sender, EventArgs e)
        {
            string userCode = this.cmbUserCode.SelectedValue.ToString();
            string name = this.txtName.Text.ToString();
            string department = this.cmbDept.SelectedValue.ToString();
            //奖惩类型
            string rewardsType = this.cmbType.SelectedText.ToString();
            //奖罚原因
            string reason = this.txtReason.Text.ToString();
            //奖罚金额
            double money = double.Parse(this.txtMoney.Text);

            DataTable dt_RyjcInfo = commonHelper.GetRyjcInfoByID(jc_id);

            if (dt_RyjcInfo.Rows.Count == 1)
            {
                //编辑记录
                dt_RyjcInfo.Rows[0]["User_id"] = userCode.Trim();
                dt_RyjcInfo.Rows[0]["Depart_id"] = department.Trim();
                dt_RyjcInfo.Rows[0]["Job_id"] = job_id;
                dt_RyjcInfo.Rows[0]["Type"] = rewardsType;
                dt_RyjcInfo.Rows[0]["Reason"] = reason;
                dt_RyjcInfo.Rows[0]["Money"] = money;
                dt_RyjcInfo.Rows[0]["datetime"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                commonHelper.EditInfo(dt_RyjcInfo);
                MessageBox.Show("数据保存成功！");
                this.Close();
            }
           
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
