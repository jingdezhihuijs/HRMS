﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class RykpAddForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        UserHelper userHelper = new UserHelper();
        string kp_id = "";
        public RykpAddForm()
        {
            InitializeComponent();
        }

        public RykpAddForm(string id, string editType)
        {
            InitializeComponent();
            kp_id = id;
            DataTable dt = commonHelper.GetRykpInfoByID(id);
            if (dt.Rows.Count > 0)
            {
                cmbUserCode.SelectedValue = dt.Rows[0]["User_id"].ToString();
                cmbDept.SelectedValue = dt.Rows[0]["Depart_id"].ToString();
                txtContent.Text = dt.Rows[0]["Kp_content"].ToString();
                txtResult.Text = dt.Rows[0]["Kp_result"].ToString();
                txtScore.Text = dt.Rows[0]["Score"].ToString();

            }
            else
            {
                MessageBox.Show("数据加载失败！");
            }

            if (editType == "View")
            {
                cmbUserCode.Enabled = false;
                cmbDept.Enabled = false;
                txtContent.Enabled = false;
                txtResult.Enabled = false;
                txtScore.Enabled = false;
                llbSave.Enabled = false;
                lblAdd.Enabled = false;
            }
        }

        /// <summary>
        /// 信息加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RykpAddForm_Load(object sender, EventArgs e)
        {
            DataTable dt = commonHelper.GetUsers();
            if (dt.Rows.Count > 0)
            {
                cmbUserCode.DisplayMember = "User_code";
                cmbUserCode.ValueMember = "id";
                cmbUserCode.DataSource = dt;
                cmbUserCode.SelectedIndex = 0;
            }

            DataTable dtDepartment = commonHelper.GetDepartment();
            if (dtDepartment.Rows.Count > 0)
            {
                cmbDept.DisplayMember = "Depart_name";
                cmbDept.ValueMember = "id";
                cmbDept.DataSource = dtDepartment;
                cmbDept.SelectedIndex = 0;
            }


        }

        /// <summary>
        /// 增加人员考评信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lblAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string userCode = this.cmbUserCode.SelectedValue.ToString();
            string name = this.txtName.Text.ToString();
            string department = this.cmbDept.SelectedValue.ToString();
            //考评内容
            string Content = this.txtContent.Text.ToString();
            //考评结果
            string result = this.txtResult.Text.ToString();
            double score = double.Parse(this.txtScore.Text);
            DataTable dt_RykpInfo = commonHelper.GetRykpInfoList("");
            //添加记录
            DataRow Nrow = dt_RykpInfo.NewRow();
            Nrow["User_id"] = userCode.Trim();
            Nrow["Depart_id"] = department.Trim();
            Nrow["Kp_content"] = Content;
            Nrow["Kp_result"] = result;
            Nrow["Score"] = score;
            Nrow["datetime"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            dt_RykpInfo.Rows.Add(Nrow);
            commonHelper.AddInfo(dt_RykpInfo);
            MessageBox.Show("数据添加成功！");
            this.Close();

        }

        /// <summary>
        /// 编辑保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbSave_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string userCode = this.cmbUserCode.SelectedValue.ToString();
            string name = this.txtName.Text.ToString();
            string department = "";
            try
            {
                department = this.cmbDept.SelectedValue.ToString();
            }
            catch { }
            //考评内容
            string Content = this.txtContent.Text.ToString();
            //考评结果
            string result = this.txtResult.Text.ToString();
            double score = double.Parse(this.txtScore.Text);

            DataTable dt_RykpInfo = commonHelper.GetRykpInfoByID(kp_id);

            if (dt_RykpInfo.Rows.Count == 1)
            {
                //编辑记录
                dt_RykpInfo.Rows[0]["User_id"] = userCode.Trim();
                dt_RykpInfo.Rows[0]["Depart_id"] = department.Trim();
                dt_RykpInfo.Rows[0]["Kp_content"] = Content;
                dt_RykpInfo.Rows[0]["Kp_result"] = result;
                dt_RykpInfo.Rows[0]["Score"] = score;

                commonHelper.EditInfo(dt_RykpInfo);
                MessageBox.Show("数据保存成功！");
            }
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 员工编号选择后改变姓名
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbUserCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt =(DataTable) cmbUserCode.DataSource;
            txtName.Text = dt.Rows[cmbUserCode.SelectedIndex]["Name"].ToString();
            cmbDept.SelectedValue = dt.Rows[cmbUserCode.SelectedIndex]["DepartId"].ToString();
        }

       
    }
}
