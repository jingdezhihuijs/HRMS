﻿namespace HRMS
{
    partial class RykpManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RykpManageForm));
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.llbEdit = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.llbExit = new System.Windows.Forms.LinkLabel();
            this.llbRefresh = new System.Windows.Forms.LinkLabel();
            this.llbView = new System.Windows.Forms.LinkLabel();
            this.llbDelete = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpBegin = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvRykp = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.考评编码 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.员工编码 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.员工姓名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.部门 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.考评内容 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.考评结果 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.考评分数 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.考评时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRykp)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(92, 592);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "条人员考评记录";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 592);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 18);
            this.label1.TabIndex = 7;
            this.label1.Text = "共有";
            // 
            // llbEdit
            // 
            this.llbEdit.AutoSize = true;
            this.llbEdit.Location = new System.Drawing.Point(64, 12);
            this.llbEdit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbEdit.Name = "llbEdit";
            this.llbEdit.Size = new System.Drawing.Size(44, 18);
            this.llbEdit.TabIndex = 17;
            this.llbEdit.TabStop = true;
            this.llbEdit.Text = "修改";
            this.llbEdit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbEdit_LinkClicked);
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.Location = new System.Drawing.Point(338, 12);
            this.linkLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(44, 18);
            this.linkLabel6.TabIndex = 16;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "皮肤";
            // 
            // llbExit
            // 
            this.llbExit.AutoSize = true;
            this.llbExit.Location = new System.Drawing.Point(280, 12);
            this.llbExit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbExit.Name = "llbExit";
            this.llbExit.Size = new System.Drawing.Size(44, 18);
            this.llbExit.TabIndex = 15;
            this.llbExit.TabStop = true;
            this.llbExit.Text = "退出";
            this.llbExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbExit_LinkClicked);
            // 
            // llbRefresh
            // 
            this.llbRefresh.AutoSize = true;
            this.llbRefresh.Location = new System.Drawing.Point(228, 12);
            this.llbRefresh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbRefresh.Name = "llbRefresh";
            this.llbRefresh.Size = new System.Drawing.Size(44, 18);
            this.llbRefresh.TabIndex = 14;
            this.llbRefresh.TabStop = true;
            this.llbRefresh.Text = "刷新";
            this.llbRefresh.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbRefresh_LinkClicked);
            // 
            // llbView
            // 
            this.llbView.AutoSize = true;
            this.llbView.Location = new System.Drawing.Point(176, 12);
            this.llbView.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbView.Name = "llbView";
            this.llbView.Size = new System.Drawing.Size(44, 18);
            this.llbView.TabIndex = 13;
            this.llbView.TabStop = true;
            this.llbView.Text = "查看";
            this.llbView.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbView_LinkClicked);
            // 
            // llbDelete
            // 
            this.llbDelete.AutoSize = true;
            this.llbDelete.Location = new System.Drawing.Point(123, 10);
            this.llbDelete.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbDelete.Name = "llbDelete";
            this.llbDelete.Size = new System.Drawing.Size(44, 18);
            this.llbDelete.TabIndex = 12;
            this.llbDelete.TabStop = true;
            this.llbDelete.Text = "删除";
            this.llbDelete.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbDelete_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.linkLabel1.Location = new System.Drawing.Point(12, 12);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(44, 18);
            this.linkLabel1.TabIndex = 11;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "增加";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // dtpEnd
            // 
            this.dtpEnd.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dtpEnd.Location = new System.Drawing.Point(766, 7);
            this.dtpEnd.Margin = new System.Windows.Forms.Padding(4);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(199, 28);
            this.dtpEnd.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(732, 12);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 18);
            this.label8.TabIndex = 9;
            this.label8.Text = "到";
            // 
            // dtpBegin
            // 
            this.dtpBegin.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dtpBegin.Location = new System.Drawing.Point(542, 6);
            this.dtpBegin.Margin = new System.Windows.Forms.Padding(4);
            this.dtpBegin.Name = "dtpBegin";
            this.dtpBegin.Size = new System.Drawing.Size(182, 28);
            this.dtpBegin.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(436, 14);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "考评日期从";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(62, 592);
            this.lblCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(17, 18);
            this.lblCount.TabIndex = 8;
            this.lblCount.Text = "8";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.llbEdit);
            this.panel1.Controls.Add(this.linkLabel6);
            this.panel1.Controls.Add(this.llbExit);
            this.panel1.Controls.Add(this.llbRefresh);
            this.panel1.Controls.Add(this.llbView);
            this.panel1.Controls.Add(this.llbDelete);
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Controls.Add(this.dtpEnd);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.dtpBegin);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(2, 13);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1080, 40);
            this.panel1.TabIndex = 5;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(972, 1);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(77, 34);
            this.btnSearch.TabIndex = 18;
            this.btnSearch.Text = "查询";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgvRykp
            // 
            this.dgvRykp.AllowUserToAddRows = false;
            this.dgvRykp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRykp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.考评编码,
            this.员工编码,
            this.员工姓名,
            this.部门,
            this.考评内容,
            this.考评结果,
            this.考评分数,
            this.考评时间});
            this.dgvRykp.Location = new System.Drawing.Point(2, 74);
            this.dgvRykp.Margin = new System.Windows.Forms.Padding(4);
            this.dgvRykp.Name = "dgvRykp";
            this.dgvRykp.RowTemplate.Height = 23;
            this.dgvRykp.Size = new System.Drawing.Size(1080, 498);
            this.dgvRykp.TabIndex = 6;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Visible = false;
            this.ID.Width = 10;
            // 
            // 考评编码
            // 
            this.考评编码.DataPropertyName = "Kp_code";
            this.考评编码.HeaderText = "考评编码";
            this.考评编码.Name = "考评编码";
            this.考评编码.Visible = false;
            this.考评编码.Width = 80;
            // 
            // 员工编码
            // 
            this.员工编码.DataPropertyName = "User_code";
            this.员工编码.HeaderText = "员工编码";
            this.员工编码.Name = "员工编码";
            this.员工编码.Width = 80;
            // 
            // 员工姓名
            // 
            this.员工姓名.DataPropertyName = "USERNAME";
            this.员工姓名.HeaderText = "员工姓名";
            this.员工姓名.Name = "员工姓名";
            this.员工姓名.Width = 80;
            // 
            // 部门
            // 
            this.部门.DataPropertyName = "Depart_name";
            this.部门.HeaderText = "部门";
            this.部门.Name = "部门";
            // 
            // 考评内容
            // 
            this.考评内容.DataPropertyName = "Kp_content";
            this.考评内容.HeaderText = "考评内容";
            this.考评内容.Name = "考评内容";
            this.考评内容.Width = 80;
            // 
            // 考评结果
            // 
            this.考评结果.DataPropertyName = "Kp_result";
            this.考评结果.HeaderText = "考评结果";
            this.考评结果.Name = "考评结果";
            // 
            // 考评分数
            // 
            this.考评分数.DataPropertyName = "Score";
            this.考评分数.HeaderText = "考评分数";
            this.考评分数.Name = "考评分数";
            this.考评分数.Width = 80;
            // 
            // 考评时间
            // 
            this.考评时间.DataPropertyName = "datetime";
            dataGridViewCellStyle1.NullValue = null;
            this.考评时间.DefaultCellStyle = dataGridViewCellStyle1;
            this.考评时间.HeaderText = "考评时间";
            this.考评时间.Name = "考评时间";
            this.考评时间.Width = 160;
            // 
            // RykpManageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1086, 626);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvRykp);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RykpManageForm";
            this.Text = "人员考评列表";
            this.Load += new System.EventHandler(this.RykpManageForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRykp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel llbEdit;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel llbExit;
        private System.Windows.Forms.LinkLabel llbRefresh;
        private System.Windows.Forms.LinkLabel llbView;
        private System.Windows.Forms.LinkLabel llbDelete;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpBegin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvRykp;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn 考评编码;
        private System.Windows.Forms.DataGridViewTextBoxColumn 员工编码;
        private System.Windows.Forms.DataGridViewTextBoxColumn 员工姓名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 部门;
        private System.Windows.Forms.DataGridViewTextBoxColumn 考评内容;
        private System.Windows.Forms.DataGridViewTextBoxColumn 考评结果;
        private System.Windows.Forms.DataGridViewTextBoxColumn 考评分数;
        private System.Windows.Forms.DataGridViewTextBoxColumn 考评时间;
        private System.Windows.Forms.Button btnSearch;
    }
}