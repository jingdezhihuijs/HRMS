﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class RykpManageForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        public RykpManageForm()
        {
            InitializeComponent();
        }
       
        /// <summary>
        /// 增加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new RykpAddForm().ShowDialog();
            DataBind();
        }

        public void RykpManageForm_Load(object sender, EventArgs e)
        {
            dtpBegin.Value = DateTime.Now.AddDays(-7);  
            DataBind();
        }

        /// <summary>
        /// 绑定主表格数据
        /// </summary>
        public void DataBind()
        {
            string strSql = "";
            string beginDate = dtpBegin.Value.ToString("yyyy-MM-dd")+" 00:00:00";
            string endDate = dtpEnd.Value.ToString("yyyy-MM-dd")+" 23:59:59";
            if (beginDate.Trim() != "")
            {
                strSql = " AND DATETIME > '" + beginDate+"'  " ;
            }
            if (endDate.Trim() != "")
            {
                strSql += " AND DATETIME <= '" + endDate + "' ";
            }
            DataTable dt_Rykp = commonHelper.GetRykpInfoListDetail(strSql);
            this.dgvRykp.AutoGenerateColumns = false;
            this.dgvRykp.DataSource = dt_Rykp;

            //判断是否有数据，有数据则将数量赋给数据量控件
            if (dgvRykp != null)
            {
                this.lblCount.Text = dgvRykp.Rows.Count.ToString();
            }
            else
            {
                this.lblCount.Text = "0";
            }
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbEdit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
            //判断是否有选中项
            if (this.dgvRykp.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvRykp.CurrentRow.Index;
                string strId = dgvRykp.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                RykpAddForm rf = new RykpAddForm(strId, "Edit");
                //显示窗体
                rf.ShowDialog();
                DataBind();

            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            }         
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataBind();
        }

        /// <summary>
        /// 查看
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbView_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //判断是否有选中项
            if (this.dgvRykp.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvRykp.CurrentRow.Index;
                string strId = dgvRykp.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                RykpAddForm rf = new RykpAddForm(strId, "View");
                //显示窗体
                rf.ShowDialog();
            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            }         
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbDelete_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ///让用户选择是否删除
            MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
            if (MessageBox.Show("确定要删除数据吗？", "删除数据", btn) == DialogResult.Yes)
            {
                //取出选中行里面绑定的对象
                int a = dgvRykp.CurrentRow.Index;
                string strId = dgvRykp.Rows[a].Cells[0].Value.ToString();
                try
                {
                    commonHelper.DeleteInfo("t_kp",strId);
                    MessageBox.Show("删除成功！");
                    //确定删除的同时刷新数据
                    DataBind(); 
                }
                catch
                {
                    MessageBox.Show("删除失败！");
                }

            }
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataBind(); 
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }



    }
}
