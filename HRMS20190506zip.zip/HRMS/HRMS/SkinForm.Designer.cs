﻿namespace HRMS
{
    partial class SkinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SkinForm));
            this.btnSetSkin = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb_mr = new System.Windows.Forms.RadioButton();
            this.rb_a = new System.Windows.Forms.RadioButton();
            this.rb_ss = new System.Windows.Forms.RadioButton();
            this.rb_zs = new System.Windows.Forms.RadioButton();
            this.rb_zml = new System.Windows.Forms.RadioButton();
            this.rb_zsl = new System.Windows.Forms.RadioButton();
            this.rb_mac = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSetSkin
            // 
            this.btnSetSkin.Location = new System.Drawing.Point(176, 299);
            this.btnSetSkin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSetSkin.Name = "btnSetSkin";
            this.btnSetSkin.Size = new System.Drawing.Size(241, 54);
            this.btnSetSkin.TabIndex = 3;
            this.btnSetSkin.Text = "设置皮肤";
            this.btnSetSkin.UseVisualStyleBackColor = true;
            this.btnSetSkin.Click += new System.EventHandler(this.btnSetSkin_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rb_mr);
            this.groupBox1.Controls.Add(this.rb_a);
            this.groupBox1.Controls.Add(this.rb_ss);
            this.groupBox1.Controls.Add(this.rb_zs);
            this.groupBox1.Controls.Add(this.rb_zml);
            this.groupBox1.Controls.Add(this.rb_zsl);
            this.groupBox1.Controls.Add(this.rb_mac);
            this.groupBox1.Location = new System.Drawing.Point(27, 31);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(580, 217);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "界面设置";
            // 
            // rb_mr
            // 
            this.rb_mr.AutoSize = true;
            this.rb_mr.Location = new System.Drawing.Point(13, 47);
            this.rb_mr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_mr.Name = "rb_mr";
            this.rb_mr.Size = new System.Drawing.Size(69, 22);
            this.rb_mr.TabIndex = 6;
            this.rb_mr.TabStop = true;
            this.rb_mr.Text = "默认";
            this.rb_mr.UseVisualStyleBackColor = true;
            // 
            // rb_a
            // 
            this.rb_a.AutoSize = true;
            this.rb_a.Location = new System.Drawing.Point(287, 127);
            this.rb_a.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_a.Name = "rb_a";
            this.rb_a.Size = new System.Drawing.Size(87, 22);
            this.rb_a.TabIndex = 5;
            this.rb_a.TabStop = true;
            this.rb_a.Text = "温馨橙";
            this.rb_a.UseVisualStyleBackColor = true;
            // 
            // rb_ss
            // 
            this.rb_ss.AutoSize = true;
            this.rb_ss.Location = new System.Drawing.Point(132, 127);
            this.rb_ss.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_ss.Name = "rb_ss";
            this.rb_ss.Size = new System.Drawing.Size(87, 22);
            this.rb_ss.TabIndex = 4;
            this.rb_ss.TabStop = true;
            this.rb_ss.Text = "深沉绿";
            this.rb_ss.UseVisualStyleBackColor = true;
            // 
            // rb_zs
            // 
            this.rb_zs.AutoSize = true;
            this.rb_zs.Location = new System.Drawing.Point(13, 127);
            this.rb_zs.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_zs.Name = "rb_zs";
            this.rb_zs.Size = new System.Drawing.Size(87, 22);
            this.rb_zs.TabIndex = 3;
            this.rb_zs.TabStop = true;
            this.rb_zs.Text = "俊朗黑";
            this.rb_zs.UseVisualStyleBackColor = true;
            // 
            // rb_zml
            // 
            this.rb_zml.AutoSize = true;
            this.rb_zml.Location = new System.Drawing.Point(422, 47);
            this.rb_zml.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_zml.Name = "rb_zml";
            this.rb_zml.Size = new System.Drawing.Size(87, 22);
            this.rb_zml.TabIndex = 2;
            this.rb_zml.TabStop = true;
            this.rb_zml.Text = "简约灰";
            this.rb_zml.UseVisualStyleBackColor = true;
            // 
            // rb_zsl
            // 
            this.rb_zsl.AutoSize = true;
            this.rb_zsl.Location = new System.Drawing.Point(287, 47);
            this.rb_zsl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_zsl.Name = "rb_zsl";
            this.rb_zsl.Size = new System.Drawing.Size(87, 22);
            this.rb_zsl.TabIndex = 1;
            this.rb_zsl.TabStop = true;
            this.rb_zsl.Text = "钻石蓝";
            this.rb_zsl.UseVisualStyleBackColor = true;
            // 
            // rb_mac
            // 
            this.rb_mac.AutoSize = true;
            this.rb_mac.Location = new System.Drawing.Point(132, 47);
            this.rb_mac.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_mac.Name = "rb_mac";
            this.rb_mac.Size = new System.Drawing.Size(96, 22);
            this.rb_mac.TabIndex = 0;
            this.rb_mac.TabStop = true;
            this.rb_mac.Text = "Mac系统";
            this.rb_mac.UseVisualStyleBackColor = true;
            // 
            // Skin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 403);
            this.Controls.Add(this.btnSetSkin);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Skin";
            this.Text = "皮肤";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSetSkin;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rb_mr;
        private System.Windows.Forms.RadioButton rb_a;
        private System.Windows.Forms.RadioButton rb_ss;
        private System.Windows.Forms.RadioButton rb_zs;
        private System.Windows.Forms.RadioButton rb_zml;
        private System.Windows.Forms.RadioButton rb_zsl;
        private System.Windows.Forms.RadioButton rb_mac;
    }
}