﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class SkinForm : Form
    {
        SkinSet skinSet = new SkinSet();
        public SkinForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 设置皮肤
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSetSkin_Click(object sender, EventArgs e)
        {
            string skin = "";
            if (rb_mac.Checked == true)
            { 
                skin = rb_mac.Text;
                skinSet.DeletePifu();
                skinSet.Pifu(skin);
            }
            else if (rb_zsl.Checked == true)
            { 
                skin = rb_zsl.Text;
                skinSet.DeletePifu();
                skinSet.Pifu(skin);
            }
            else if (rb_zml.Checked == true)
            { 
                skin = rb_zml.Text;
                skinSet.DeletePifu();
                skinSet.Pifu(skin);
            }
            else if (rb_zs.Checked == true)
            { 
                skin = rb_zs.Text;
                skinSet.DeletePifu();
                skinSet.Pifu(skin);
            }
            else if (rb_ss.Checked == true)
            { 
                skin = rb_ss.Text;
                skinSet.DeletePifu();
                skinSet.Pifu(skin);
            }
            else if (rb_a.Checked == true)
            { 
                skin = rb_a.Text;
                skinSet.DeletePifu();
                skinSet.Pifu(skin);
            }
            else if (rb_mr.Checked == true)
            { 
                skin = rb_mr.Text;
                skinSet.DeletePifu();
                skinSet.Pifu(skin);
            }
            MessageBox.Show("界面设置成功，重新登录系统即可生效！");
            this.Close();
        }
    }
}
