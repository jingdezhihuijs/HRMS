﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class StaffAddForm : Form
    {
        UserHelper userHelper = new UserHelper();
        CommonHelper commonHelper = new CommonHelper();
        bool isUpLoadPicture = false;
        string empUpLoadPictureRealPos = "";

        //用来存储传递来的主键值
        private string ID = "";
        private string EditType = "ADD";

        public StaffAddForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 重写员工基本信息载入
        /// </summary>
        /// <param name="ID"></param>
        public StaffAddForm(string ID,string EditType)
        {
            InitializeComponent();
            this.ID = ID;
            this.EditType = EditType;
            DataLoad(ID);

            //查看功能禁止对内容进行操作
            if (EditType == "View")
            {
                this.txtUserCode.Enabled = false;
                this.txtUserName.Enabled = false;
                this.txtPhone.Enabled = false;
                this.cmbSex.Enabled = false;
                this.txtCardID.Enabled = false;
                this.txtEdu.Enabled = false;
                this.txtEmail.Enabled = false;
                this.cmdJob.Enabled = false;
                this.cmbTitle_tech.Enabled = false;
                this.cmbDept.Enabled = false;
                this.txtMobile.Enabled = false;
                this.txtPhone.Enabled = false;
                this.cmbType.Enabled = false;
                this.cmbNation.Enabled = false;
                this.txtAddr.Enabled = false;
                this.tsbAdd.Enabled = false;
                this.tsbSave.Enabled = false;
                this.tsbPhoto.Enabled = false;

            }
            
        }

        /// <summary>
        /// 根据ID加载员工信息
        /// </summary>
        /// <param name="ID"></param>
        public void DataLoad(string ID)
        {
            DataTable dt_userInfo = userHelper.GetUserInfoById(ID);
            if (dt_userInfo.Rows.Count ==0)
            { MessageBox.Show("员工信息获取异常，请重新获取"); return; }
            txtUserCode.Text = dt_userInfo.Rows[0]["User_Code"].ToString();
            txtUserName.Text = dt_userInfo.Rows[0]["Name"].ToString();
            cmbSex.SelectedItem = dt_userInfo.Rows[0]["Sex"].ToString();
            txtCardID.Text = dt_userInfo.Rows[0]["ID_Card"].ToString();
            txtEdu.Text = dt_userInfo.Rows[0]["Edu"].ToString();
            txtEmail.Text = dt_userInfo.Rows[0]["Email"].ToString();
            cmdJob.SelectedItem = dt_userInfo.Rows[0]["Job_id"].ToString();
            cmbTitle_tech.SelectedItem = dt_userInfo.Rows[0]["Title_tech"].ToString();
            cmbDept.SelectedItem = dt_userInfo.Rows[0]["DepartId"].ToString();
            txtMobile.Text = dt_userInfo.Rows[0]["Mobile"].ToString();
            txtPhone.Text = dt_userInfo.Rows[0]["Phone"].ToString();
            cmbType.Text = dt_userInfo.Rows[0]["Type"].ToString();
            cmbNation.SelectedItem = dt_userInfo.Rows[0]["Nation"].ToString();
            txtAddr.Text = dt_userInfo.Rows[0]["Address"].ToString();
            if (dt_userInfo.Rows[0]["Img"] != null && dt_userInfo.Rows[0]["Img"].ToString().Trim() != "")
            {
                PbPhoto.Image = Image.FromFile(dt_userInfo.Rows[0]["Img"].ToString());
            }

        }

        /// <summary>
        /// 编辑员工信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbSave_Click(object sender, EventArgs e)
        {
            string UserCode = "";     //编号
            string UserName = "";     //名称
            string Sex = "";         //性别
            string IDCard = "";     //身份证号码
            string Edu = "";       //学历
            string Email = "";     //邮箱
            string Job_id = "";    //职务
            string Title_tech = ""; //职称
            string Department = ""; //部门
            string Mobile = "";   //固话
            string Phone = "";    //手机
            string Type = "";    //类型
            string Nation = ""; //民族
            string Address = "";//地址
            string Image = ""; //照片

            if (this.txtUserCode.Text == "") { MessageBox.Show("请输入编号登录名！"); return; }
            if (this.txtUserName.Text == "") { MessageBox.Show("请输入姓名！"); return; }
            if (this.txtCardID.Text.Length > 18) { MessageBox.Show("身份证号码不能超过18位，请重新输入！"); return; }

            UserCode = txtUserCode.Text.ToString();
            UserName = txtUserName.Text.ToString();
            Sex = cmbSex.Text.ToString();
            IDCard = txtCardID.Text.ToString();
            Edu = txtEdu.Text.ToString();
            Email = txtEmail.Text.ToString();
            Job_id = cmdJob.SelectedValue.ToString();
            Title_tech = cmbTitle_tech.SelectedItem.ToString();
            Department = cmbDept.SelectedValue.ToString();
            Mobile = txtMobile.Text.ToString();
            Phone = txtPhone.Text.ToString();
            Type = cmbType.Text.ToString();
            Nation = cmbNation.Text.ToString();
            Address = txtAddr.Text.ToString();
            if (isUpLoadPicture == true)
            {
                Image = empUpLoadPictureRealPos;
            }
            //修改数据之前首先要判断是否已经存在这个名称跟编号了
            //根据用户名查询用户信息
            DataTable dt_userInfo = userHelper.GetUserInfo(UserName, UserCode);
            if (dt_userInfo.Rows.Count>1)
               { MessageBox.Show("员工姓名编号重复！"); return; }

            if (dt_userInfo.Rows.Count == 1)
            {
                //编辑记录
                dt_userInfo.Rows[0]["User_Code"] = UserCode.Trim();
                dt_userInfo.Rows[0]["Name"] = UserName.Trim();
                dt_userInfo.Rows[0]["Sex"] = Sex.Trim();
                dt_userInfo.Rows[0]["ID_Card"] = IDCard;
                dt_userInfo.Rows[0]["Edu"] = Edu;
                dt_userInfo.Rows[0]["Email"] = Email;
                dt_userInfo.Rows[0]["Job_id"] = Job_id;
                dt_userInfo.Rows[0]["Title_tech"] = Title_tech;
                dt_userInfo.Rows[0]["DepartId"] = Department;
                dt_userInfo.Rows[0]["Mobile"] = Mobile;
                dt_userInfo.Rows[0]["Phone"] = Phone;
                dt_userInfo.Rows[0]["Type"] = Type;
                dt_userInfo.Rows[0]["Nation"] = Nation;
                dt_userInfo.Rows[0]["Address"] = Address;
                if (isUpLoadPicture == true)
                {
                    dt_userInfo.Rows[0]["Img"] = empUpLoadPictureRealPos;
                }
                userHelper.EditUserInfo(dt_userInfo);
                MessageBox.Show("数据保存成功！");
                this.Close();
            }

        }

        /// <summary>
        /// 新增员工信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbAdd_Click(object sender, EventArgs e)
        {
            string UserCode = "";     //编号
            string UserName = "";     //名称
            string Sex = "";         //性别
            string IDCard = "";     //身份证号码
            string Edu = "";       //学历
            string Email = "";     //邮箱
            string Job_id = "";    //职务
            string Title_tech = ""; //职称
            string Department = ""; //部门
            string Mobile = "";   //固话
            string Phone = "";    //手机
            string Type = "";    //类型
            string Nation = ""; //民族
            string Address = "";//地址
            string Image = ""; //照片

            if (this.txtUserCode.Text == "") { MessageBox.Show("请输入编号登录名！"); return; }
            if (this.txtUserName.Text == "") { MessageBox.Show("请输入姓名！"); return; }
            if (this.txtCardID.Text.Length > 18) { MessageBox.Show("身份证号码不能超过18位，请重新输入！"); return; }

            UserCode = txtUserCode.Text.ToString();
            UserName = txtUserName.Text.ToString();
            Sex = cmbSex.Text.ToString();
            IDCard = txtCardID.Text.ToString();
            Edu = txtEdu.Text.ToString();
            Email = txtEmail.Text.ToString();
            Job_id = cmdJob.SelectedValue.ToString();
            Title_tech = cmbTitle_tech.SelectedItem.ToString();
            Department = cmbDept.SelectedValue.ToString();
            Mobile = txtMobile.Text.ToString();
            Phone = txtPhone.Text.ToString();
            Type = cmbType.Text.ToString();
            Nation = cmbNation.Text.ToString();
            Address = txtAddr.Text.ToString();
            if (isUpLoadPicture == true)
            {
                Image = empUpLoadPictureRealPos;
            }
            //修改数据之前首先要判断是否已经存在这个名称跟编号了
            //根据用户名查询用户信息
            DataTable dt_userInfo = userHelper.GetUserInfo(UserName, UserCode);
            if (dt_userInfo.Rows.Count > 0)
            { MessageBox.Show("员工姓名编号重复！"); return; }

            //添加记录
            DataRow Nrow = dt_userInfo.NewRow();
            Nrow["User_Code"] = UserCode.Trim();
            Nrow["Name"] = UserName.Trim();
            Nrow["Sex"] = Sex.Trim();
            Nrow["ID_Card"] = IDCard;
            Nrow["Edu"] = Edu;
            Nrow["Email"] = Email;
            Nrow["Job_id"] = Job_id;
            Nrow["Title_tech"] = Title_tech;
            Nrow["DepartId"] = Department;
            Nrow["Mobile"] = Mobile;
            Nrow["Phone"] = Phone;
            Nrow["Type"] = Type;
            Nrow["Nation"] = Nation;
            Nrow["Address"] = Address;
            Nrow["Img"] = Image;
            dt_userInfo.Rows.Add(Nrow);
            userHelper.AddUserInfo(dt_userInfo);
            MessageBox.Show("数据添加成功！");
            this.Close();
        }

        /// <summary>
        /// 上传照片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbPhoto_Click(object sender, EventArgs e)
        {
            
            
            try
            {
                openFileDialog1.Filter = "*.jpg|*.jpg|*.png|*.png|*.bmp|*.bmp|*.tiff|*.tiff";//图片格式
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    isUpLoadPicture = true;//记录是否上传了相片，用于后面保存操作使用：是一个成员变量
                    try
                    {
                        empUpLoadPictureRealPos = openFileDialog1.FileName;//实际的文件路径+文件名
                        String[] empImageData = empUpLoadPictureRealPos.Split('.');

                        //empImageData[1]:是上传的图片的后缀名

                      //  empUpLoadPictureFormat = empImageData[1];

                        PbPhoto.Image = Image.FromFile(empUpLoadPictureRealPos);//将图片显示在pitureBox控件中
                    }
                    catch
                    {
                        MessageBox.Show("您选择的图片不能被读取或文件类型不对！", "错误信息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("上传相片出错: " + ex.Message);
            }
        }

        /// <summary>
        /// 打印
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbPrint_Click(object sender, EventArgs e)
        {
            this.printDialog1.PrinterSettings.PrinterName = "Microsoft XPS Document Writer";

            this.printDocument1.Print();

        }

        /// <summary>
        /// 打印内容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //打印内容 为 局部的 this.plControl
            Bitmap _NewBitmap = new Bitmap(plControl.Width, plControl.Height);
            plControl.DrawToBitmap(_NewBitmap, new Rectangle(0, 0, _NewBitmap.Width, _NewBitmap.Height));
            e.Graphics.DrawImage(_NewBitmap, 0, 0, _NewBitmap.Width, _NewBitmap.Height);
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 人员信息表加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StaffAddForm_Load(object sender, EventArgs e)
        {
            //性别
            DataTable dt_sex = commonHelper.GetDictInfo("sex");
            if (dt_sex.Rows.Count > 0)
            {
                cmbSex.DisplayMember = "Dict_name";
                cmbSex.ValueMember = "id";
                cmbSex.DataSource = dt_sex;
                cmbSex.SelectedIndex = 0;
            }

            //民族
            DataTable dt_nation = commonHelper.GetDictInfo("minzu");
            if (dt_nation.Rows.Count > 0)
            {
                cmbNation.DisplayMember = "Dict_name";
                cmbNation.ValueMember = "id";
                cmbNation.DataSource = dt_nation;
                cmbNation.SelectedIndex = 0;
            }

            //职位
            DataTable dt_job = commonHelper.GetDictInfo("zhiwei");
            if (dt_job.Rows.Count > 0)
            {
                cmdJob.DisplayMember = "Dict_name";
                cmdJob.ValueMember = "id";
                cmdJob.DataSource = dt_job;
                cmdJob.SelectedIndex = 0;
            }

            //部门
            DataTable dt_dept = commonHelper.GetDepartment();
            if (dt_dept.Rows.Count > 0)
            {
                cmbDept.DisplayMember = "Depart_name";
                cmbDept.ValueMember = "id";
                cmbDept.DataSource = dt_dept;
                cmbDept.SelectedIndex = 0;
            }
        }

    }
}
