﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class StaffRecordsForm : Form
    {
        UserHelper userHelper = new UserHelper();
        public StaffRecordsForm()
        {
            InitializeComponent();
        }

        private void StaffRecordsForm_Load(object sender, EventArgs e)
        {
            //从数据库中读取数据，通过递归生成树。
            InitTree(this.tvDepartment.Nodes, "0");
            LoadStaffRocords();

        }
        /// <summary>
        /// 部门列表树的初始化
        /// </summary>
        /// <param name="Nds">节点</param>
        /// <param name="parentId">父id</param>
        private void InitTree(TreeNodeCollection Nds, string parentId)
        {
            //定义DataView
            DataView dv = new DataView();
            //临时树节点
            TreeNode tmpNd;
            string intId;
            //获取部门信息
            DataTable dt = userHelper.GetDepartments();
            dv.Table = dt;
            dv.RowFilter = "Parent_ID='" + parentId + "'";
            foreach (DataRowView drv in dv)
            {
                //创建树节点
                tmpNd = new TreeNode();
                tmpNd.Tag = drv["id"].ToString();
                tmpNd.Text = drv["Depart_name"].ToString();
                //将节点加到树上面
                Nds.Add(tmpNd);
                intId = drv["Parent_ID"].ToString();
                //递归加载生成树
                InitTree(tmpNd.Nodes, tmpNd.Tag.ToString());
            }
        }


        /// <summary>
        /// 加载员工档案信息
        /// </summary>
        private void LoadStaffRocords()
        {
            string strWhere = "";
            //判断查询内容是否为空，如果非空则判断是选择的哪项查询
            if (txtSearch.Text.Trim() != "")
            {
                //以编号查询
                if (rbNumber.Checked)
                {
                    strWhere = " t.User_code like '%" + txtSearch.Text.ToString().Trim() + "%'  ";
                }
                //以名称查询
                else
                {
                    strWhere = " t.Name like '%" + txtSearch.Text.ToString().Trim() + "%'  ";
                }
            }
            //查询并绑定数据
            BindingSource bs = new BindingSource();
            System.Data.DataTable dt_staffrecords = userHelper.GetUserInfoList(strWhere);
            bs.DataSource = dt_staffrecords;
            this.dgvStaffInfo.DataSource = bs;
            //禁用列的自动生成
            dgvStaffInfo.AutoGenerateColumns = false;
        }

        /// <summary>
        /// 新增员工
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new StaffAddForm().Show();
            LoadStaffRocords();
        }

        /// <summary>
        /// 员工编辑
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 修改ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //判断是否有选中项
            if (dgvStaffInfo.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvStaffInfo.CurrentRow.Index;
                string strId = dgvStaffInfo.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                //XiuGai xg = new XiuGai();——应用单例模式控制只出现一个修改窗口
                StaffAddForm xg = new StaffAddForm(strId,"Edit");
                //显示窗体
                xg.Show();
                LoadStaffRocords();
            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            }

            
        }

        /// <summary>
        /// 员工信息删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ///让用户选择是否删除
            MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
            if (MessageBox.Show("确定要删除数据吗？", "删除数据", btn) == DialogResult.Yes)
            {
                //取出选中行里面绑定的对象
                int a = dgvStaffInfo.CurrentRow.Index;
                string strId = dgvStaffInfo.Rows[a].Cells[0].Value.ToString();
                if (strId =="5AE161C8-D620-4EAA-921F-650A207AF16F")
                {
                    MessageBox.Show("系统用户禁止删除！"); return;
                }
               try
                {
                   userHelper.DeleteUserInfo(strId);
                    MessageBox.Show("删除成功！");
                    //确定删除的同时刷新数据
                    LoadStaffRocords();
                }
                catch
                {
                    MessageBox.Show("删除失败！");
                }
               
            }

        }

        /// <summary>
        /// 查看员工信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 查找ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //判断是否有选中项
            if (dgvStaffInfo.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvStaffInfo.CurrentRow.Index;
                string strId = dgvStaffInfo.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                //XiuGai xg = new XiuGai();——应用单例模式控制只出现一个修改窗口
                StaffAddForm xg = new StaffAddForm(strId,"View");
                //显示窗体
                xg.Show();
            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            }
        }

        /// <summary>
        /// 退出人员信息列表
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tmiExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 人员信息列表查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadStaffRocords();
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadStaffRocords();
        }

        /// <summary>
        /// 导出EXCEL数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExport_Click(object sender, EventArgs e)
        {
            MessageBox.Show("导出成功！请稍等");
            //建立Excel对象
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            excel.Application.Workbooks.Add(true);
            excel.Visible = true;
            //生成字段名称
            for (int i = 0; i < dgvStaffInfo.ColumnCount; i++)
            {
                excel.Cells[1, i + 1] = dgvStaffInfo.Columns[i].HeaderText;
            }
            //填充数据
            for (int i = 0; i < dgvStaffInfo.RowCount - 1; i++)
            {
                for (int j = 0; j < dgvStaffInfo.ColumnCount; j++)
                {
                    if (dgvStaffInfo[j, i].ValueType == typeof(string))
                    {
                        excel.Cells[i + 2, j + 1] = "'" + dgvStaffInfo[j, i].Value.ToString();
                    }
                    else
                    {
                        excel.Cells[i + 2, j + 1] = dgvStaffInfo[j, i].Value.ToString();
                    }
                }
            }

        }

        /// <summary>
        /// 树选择事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tvDepartment_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string strWhere = "";
            string deptId = this.tvDepartment.SelectedNode.Tag.ToString();

            if (txtSearch.Text.Trim() != "")
            {
                if (rbNumber.Checked)
                {
                    strWhere = " AND t.User_code like '%" + txtSearch.Text.ToString() + "%'  ";
                }
                else
                {
                    strWhere = " AND t.Name like '%" + txtSearch.Text.ToString() + "%'  ";
                }
            }

            strWhere += string.Format(@" AND t.DepartId  = '{0}'", deptId);
            BindingSource bs = new BindingSource();
            System.Data.DataTable dt_staffrecords = userHelper.GetUserInfoList(strWhere);
            bs.DataSource = dt_staffrecords;
            this.dgvStaffInfo.DataSource = bs;
            dgvStaffInfo.AutoGenerateColumns = false;
        }
    }
}
