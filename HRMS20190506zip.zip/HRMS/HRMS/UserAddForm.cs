﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class UserAddForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        UserHelper userHelper = new UserHelper();
        string userid = "";
        public UserAddForm()
        {
            InitializeComponent();
        }

        private void UserAddForm_Load(object sender, EventArgs e)
        {
            DataTable dt = commonHelper.GetUsers();
            if (dt.Rows.Count > 0)
            {
                cmbUser.DisplayMember = "CodeName";
                cmbUser.ValueMember = "id";
                cmbUser.DataSource = dt;
                cmbUser.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// 增加员工信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text.ToString().Trim() == "")
            {
                MessageBox.Show("员工信息不能为空！请输入员工信息");
                return;
            }
            if (txtPassword.Text.ToString().Trim() == "")
            {
                MessageBox.Show("请输入密码！");
                return;
            }
            if (txtPwdC.Text.ToString().Trim() == "")
            {
                MessageBox.Show("请输入确认密码！");
                return;
            }
            if (txtPassword.Text.ToString() != txtPwdC.Text.ToString())
            {
                MessageBox.Show("两次密码输入值不同，请重新输入");
                return;
            }

            string userName = txtUserName.Text.ToString().Trim();
            DataTable dt_userInfo = commonHelper.GetUserInfo(userName);
            if (dt_userInfo.Rows.Count > 0)
            { MessageBox.Show("用户名重复！"); return; }

            DataTable dt_User = userHelper.GetUserInfoById(userid);

            //编辑数据
            if (dt_User.Rows.Count > 0)
            {
                dt_User.Rows[0]["UserName"] = userName;
                dt_User.Rows[0]["Password"] = txtPassword.Text.ToString();
                userHelper.EditUserInfo(dt_User);
                MessageBox.Show("用户添加成功！");
                this.Close();
            }
            
        }

        /// <summary>
        /// 用户选择变换
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)cmbUser.DataSource;
            string UserName = dt.Rows[cmbUser.SelectedIndex]["UserName"].ToString();
            txtUserCode.Text = dt.Rows[cmbUser.SelectedIndex]["User_code"].ToString();
            userid = dt.Rows[cmbUser.SelectedIndex]["id"].ToString();
            if (UserName != "0")
            {
                btnSave.Enabled = false;
                return;
            }
            else
            {
                btnSave.Enabled = true;
            }
            

        }

        /// <summary>
        /// 清空信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            InitializeComponent();
        }

       
    }
}
