﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class UserManageForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        public UserManageForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //判断是否有选中项
            if (this.dgvUsers.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvUsers.CurrentRow.Index;
                string strId = dgvUsers.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                PasswordEditForm rf = new PasswordEditForm(strId, "Edit");
                //显示窗体
                rf.ShowDialog();
                DataBind();

            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            }         
        }

        /// <summary>
        /// 添加用户
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            new UserAddForm().Show();
        }

        /// <summary>
        /// 加载数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserManageForm_Load(object sender, EventArgs e)
        {
            DataBind();
        }

        /// <summary>
        /// 绑定主表格数据
        /// </summary>
        public void DataBind()
        {
            string strSql = "";
            DataTable dt_User = commonHelper.GetUserInfo(strSql);
            this.dgvUsers.AutoGenerateColumns = false;
            this.dgvUsers.DataSource = dt_User;
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            DataBind();
        }

        private void tsbExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
