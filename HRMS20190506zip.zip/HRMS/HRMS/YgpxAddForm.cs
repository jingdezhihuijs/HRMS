﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class YgpxAddForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        UserHelper userHelper = new UserHelper();
        string px_id = "";
        public YgpxAddForm()
        {
            InitializeComponent();
        }

        private void YgpxAddForm_Load(object sender, EventArgs e)
        {
            DataBind();
            DataTable dt = commonHelper.GetUsers();
            if (dt.Rows.Count > 0)
            {
                cmbUserName.DisplayMember = "CodeName";
                cmbUserName.ValueMember = "id";
                cmbUserName.DataSource = dt;
                cmbUserName.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// 绑定主表格数据
        /// </summary>
        public void DataBind()
        {
            string strSql = "";
            DataTable dt_Rypx = commonHelper.GetYgpxInfoListDetail(strSql);
            this.dgvYgpx.AutoGenerateColumns = false;
            this.dgvYgpx.DataSource = dt_Rypx;
        }

        public YgpxAddForm(string id, string editType)
        {
            InitializeComponent();
            
            px_id = id;
            DataTable dt = commonHelper.GetYgpxInfoByID(id);
            if (dt.Rows.Count > 0)
            {
                cmbUserName.SelectedValue = dt.Rows[0]["User_id"].ToString();
                txtContent.Text = dt.Rows[0]["Train_content"].ToString();
                txtAddr.Text = dt.Rows[0]["Addr"].ToString();
                txtScore.Text = dt.Rows[0]["Score"].ToString();
                dtpBeginDate.Value = DateTime.Parse(dt.Rows[0]["Start_date"].ToString());
                dtpEndDate.Value = DateTime.Parse(dt.Rows[0]["End_date"].ToString());
            }
            else
            {
                MessageBox.Show("数据加载失败！");
            }

            if (editType == "View")
            {
                cmbUserName.Enabled = false;
                txtContent.Enabled = false;
                txtAddr.Enabled = false;
                txtScore.Enabled = false;
                dtpBeginDate.Enabled = false;
                dtpEndDate.Enabled = false;
            }
        }

        /// <summary>
        /// 增加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbAdd_Click(object sender, EventArgs e)
        {
            if (this.cmbUserName.SelectedValue.ToString().Trim() == "")
            {
                MessageBox.Show("员工名称不能为空！");
                return;
            }
            if (this.txtScore.Text.ToString().Trim() == "")
            {
                MessageBox.Show("培训成绩不能为空！");
                return;
            }
            if (this.txtContent.Text.ToString().Trim() == "")
            {
                MessageBox.Show("培训内容不能为空！");
                return;
            }
            if (this.txtAddr.Text.ToString().Trim() == "")
            {
                MessageBox.Show("培训地址不能为空！");
                return;
            }
            try
            {
                DataTable dt_YgpxInfo = commonHelper.GetYgpxInfoList("");
                //添加记录
                DataRow Nrow = dt_YgpxInfo.NewRow();
                Nrow["User_id"] = this.cmbUserName.SelectedValue.ToString();
                Nrow["Train_content"] = this.txtContent.Text.ToString().Trim();
                Nrow["Score"] = this.txtScore.Text.ToString().Trim();
                Nrow["Addr"] = this.txtAddr.Text.ToString().Trim();
                Nrow["Start_date"] = this.dtpBeginDate.Value.ToString("yyyy-MM-dd");
                Nrow["End_date"] = this.dtpEndDate.Value.ToString("yyyy-MM-dd");
                dt_YgpxInfo.Rows.Add(Nrow);
                commonHelper.AddInfo(dt_YgpxInfo);
                MessageBox.Show("数据添加成功！");
                this.txtContent.Text = "";
                this.txtScore.Text = "";
                this.txtAddr.Text = "";
                DataBind();
            }
            catch { }
        }

        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbEdit_Click(object sender, EventArgs e)
        {
            if (this.cmbUserName.SelectedValue.ToString().Trim() == "")
            {
                MessageBox.Show("员工名称不能为空！");
                return;
            }
            if (this.txtScore.Text.ToString().Trim() == "")
            {
                MessageBox.Show("培训成绩不能为空！");
                return;
            }
            if (this.txtContent.Text.ToString().Trim() == "")
            {
                MessageBox.Show("培训内容不能为空！");
                return;
            }
            if (this.txtAddr.Text.ToString().Trim() == "")
            {
                MessageBox.Show("培训地址不能为空！");
                return;
            }
            try
            {
                DataTable dt_YgpxInfo = commonHelper.GetYgpxInfoByID(px_id);

                if (dt_YgpxInfo.Rows.Count == 1)
                {
                    //编辑记录
                    dt_YgpxInfo.Rows[0]["User_id"] = this.cmbUserName.SelectedValue.ToString();
                    dt_YgpxInfo.Rows[0]["Train_content"] = this.txtContent.Text.ToString().Trim();
                    dt_YgpxInfo.Rows[0]["Score"] = this.txtScore.Text.ToString().Trim();
                    dt_YgpxInfo.Rows[0]["Addr"] = this.txtAddr.Text.ToString().Trim();
                    dt_YgpxInfo.Rows[0]["Start_date"] = this.dtpBeginDate.Value.ToString("yyyy-MM-dd");
                    dt_YgpxInfo.Rows[0]["End_date"] = this.dtpEndDate.Value.ToString("yyyy-MM-dd");
                    commonHelper.EditInfo(dt_YgpxInfo);
                    MessageBox.Show("数据保存成功！");
                    DataBind();
                }  
            }
            catch { }
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsbExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 行选择变换
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvYgpx_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //取出选中项的主键值
                int a = e.RowIndex;
                px_id = dgvYgpx.Rows[a].Cells[0].Value.ToString();
                cmbUserName.SelectedValue = dgvYgpx.Rows[a].Cells[1].Value.ToString();
                txtContent.Text = dgvYgpx.Rows[a].Cells[4].Value.ToString();
                txtAddr.Text = dgvYgpx.Rows[a].Cells[6].Value.ToString();
                txtScore.Text = dgvYgpx.Rows[a].Cells[5].Value.ToString();
                dtpBeginDate.Value = DateTime.Parse(dgvYgpx.Rows[a].Cells[7].Value.ToString());
                dtpEndDate.Value = DateTime.Parse(dgvYgpx.Rows[a].Cells[8].Value.ToString());
            }
            catch
            {
                MessageBox.Show("没有选中任何项！");
            }      
        }
    }
}
