﻿namespace HRMS
{
    partial class YgpxManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YgpxManageForm));
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.llbEdit = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.llbExit = new System.Windows.Forms.LinkLabel();
            this.llbRefresh = new System.Windows.Forms.LinkLabel();
            this.llbView = new System.Windows.Forms.LinkLabel();
            this.llbDelete = new System.Windows.Forms.LinkLabel();
            this.llbAdd = new System.Windows.Forms.LinkLabel();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpBegin = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvYgpx = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.序号 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.培训人员 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.培训内容 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.培训成绩 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.培训地址 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.开始时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.结束时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYgpx)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 590);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "条人员考评记录";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 590);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 18);
            this.label1.TabIndex = 7;
            this.label1.Text = "共有";
            // 
            // llbEdit
            // 
            this.llbEdit.AutoSize = true;
            this.llbEdit.Location = new System.Drawing.Point(82, 18);
            this.llbEdit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbEdit.Name = "llbEdit";
            this.llbEdit.Size = new System.Drawing.Size(44, 18);
            this.llbEdit.TabIndex = 17;
            this.llbEdit.TabStop = true;
            this.llbEdit.Text = "修改";
            this.llbEdit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbEdit_LinkClicked);
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.Location = new System.Drawing.Point(356, 18);
            this.linkLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(44, 18);
            this.linkLabel6.TabIndex = 16;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "皮肤";
            // 
            // llbExit
            // 
            this.llbExit.AutoSize = true;
            this.llbExit.Location = new System.Drawing.Point(298, 18);
            this.llbExit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbExit.Name = "llbExit";
            this.llbExit.Size = new System.Drawing.Size(44, 18);
            this.llbExit.TabIndex = 15;
            this.llbExit.TabStop = true;
            this.llbExit.Text = "退出";
            this.llbExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbExit_LinkClicked);
            // 
            // llbRefresh
            // 
            this.llbRefresh.AutoSize = true;
            this.llbRefresh.Location = new System.Drawing.Point(246, 18);
            this.llbRefresh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbRefresh.Name = "llbRefresh";
            this.llbRefresh.Size = new System.Drawing.Size(44, 18);
            this.llbRefresh.TabIndex = 14;
            this.llbRefresh.TabStop = true;
            this.llbRefresh.Text = "刷新";
            this.llbRefresh.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbRefresh_LinkClicked);
            // 
            // llbView
            // 
            this.llbView.AutoSize = true;
            this.llbView.Location = new System.Drawing.Point(194, 18);
            this.llbView.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbView.Name = "llbView";
            this.llbView.Size = new System.Drawing.Size(44, 18);
            this.llbView.TabIndex = 13;
            this.llbView.TabStop = true;
            this.llbView.Text = "查找";
            this.llbView.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbView_LinkClicked);
            // 
            // llbDelete
            // 
            this.llbDelete.AutoSize = true;
            this.llbDelete.Location = new System.Drawing.Point(141, 18);
            this.llbDelete.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbDelete.Name = "llbDelete";
            this.llbDelete.Size = new System.Drawing.Size(44, 18);
            this.llbDelete.TabIndex = 12;
            this.llbDelete.TabStop = true;
            this.llbDelete.Text = "删除";
            this.llbDelete.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbDelete_LinkClicked);
            // 
            // llbAdd
            // 
            this.llbAdd.AutoSize = true;
            this.llbAdd.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.llbAdd.Location = new System.Drawing.Point(30, 18);
            this.llbAdd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbAdd.Name = "llbAdd";
            this.llbAdd.Size = new System.Drawing.Size(44, 18);
            this.llbAdd.TabIndex = 11;
            this.llbAdd.TabStop = true;
            this.llbAdd.Text = "增加";
            this.llbAdd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbAdd_LinkClicked);
            // 
            // dtpEnd
            // 
            this.dtpEnd.Location = new System.Drawing.Point(834, 9);
            this.dtpEnd.Margin = new System.Windows.Forms.Padding(4);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(180, 28);
            this.dtpEnd.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(800, 18);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 18);
            this.label8.TabIndex = 9;
            this.label8.Text = "到";
            // 
            // dtpBegin
            // 
            this.dtpBegin.Location = new System.Drawing.Point(601, 9);
            this.dtpBegin.Margin = new System.Windows.Forms.Padding(4);
            this.dtpBegin.Name = "dtpBegin";
            this.dtpBegin.Size = new System.Drawing.Size(191, 28);
            this.dtpBegin.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(482, 18);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "培训日期从";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(67, 590);
            this.lblCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(17, 18);
            this.lblCount.TabIndex = 8;
            this.lblCount.Text = "0";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Controls.Add(this.llbEdit);
            this.panel1.Controls.Add(this.linkLabel6);
            this.panel1.Controls.Add(this.llbExit);
            this.panel1.Controls.Add(this.llbRefresh);
            this.panel1.Controls.Add(this.llbView);
            this.panel1.Controls.Add(this.llbDelete);
            this.panel1.Controls.Add(this.llbAdd);
            this.panel1.Controls.Add(this.dtpEnd);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.dtpBegin);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(2, 3);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1478, 52);
            this.panel1.TabIndex = 5;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(1021, 9);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 28);
            this.btnSearch.TabIndex = 18;
            this.btnSearch.Text = "查询";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgvYgpx
            // 
            this.dgvYgpx.AllowUserToAddRows = false;
            this.dgvYgpx.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvYgpx.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.序号,
            this.培训人员,
            this.培训内容,
            this.培训成绩,
            this.培训地址,
            this.开始时间,
            this.结束时间});
            this.dgvYgpx.Location = new System.Drawing.Point(2, 63);
            this.dgvYgpx.Margin = new System.Windows.Forms.Padding(4);
            this.dgvYgpx.Name = "dgvYgpx";
            this.dgvYgpx.RowTemplate.Height = 23;
            this.dgvYgpx.Size = new System.Drawing.Size(1112, 502);
            this.dgvYgpx.TabIndex = 6;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "id";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Visible = false;
            // 
            // 序号
            // 
            this.序号.DataPropertyName = "ROWNUM";
            this.序号.HeaderText = "序号";
            this.序号.Name = "序号";
            // 
            // 培训人员
            // 
            this.培训人员.DataPropertyName = "UserName";
            this.培训人员.HeaderText = "培训人员";
            this.培训人员.Name = "培训人员";
            // 
            // 培训内容
            // 
            this.培训内容.DataPropertyName = "Train_content";
            this.培训内容.HeaderText = "培训内容";
            this.培训内容.Name = "培训内容";
            // 
            // 培训成绩
            // 
            this.培训成绩.DataPropertyName = "Score";
            this.培训成绩.HeaderText = "培训成绩";
            this.培训成绩.Name = "培训成绩";
            // 
            // 培训地址
            // 
            this.培训地址.DataPropertyName = "Addr";
            this.培训地址.HeaderText = "培训地址";
            this.培训地址.Name = "培训地址";
            // 
            // 开始时间
            // 
            this.开始时间.DataPropertyName = "Start_date";
            this.开始时间.HeaderText = "开始时间";
            this.开始时间.Name = "开始时间";
            // 
            // 结束时间
            // 
            this.结束时间.DataPropertyName = "End_date";
            this.结束时间.HeaderText = "结束时间";
            this.结束时间.Name = "结束时间";
            // 
            // YgpxManageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 621);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvYgpx);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "YgpxManageForm";
            this.Text = "员工培训管理";
            this.Load += new System.EventHandler(this.YgpxManageForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYgpx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel llbEdit;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel llbExit;
        private System.Windows.Forms.LinkLabel llbRefresh;
        private System.Windows.Forms.LinkLabel llbView;
        private System.Windows.Forms.LinkLabel llbDelete;
        private System.Windows.Forms.LinkLabel llbAdd;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpBegin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvYgpx;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn 序号;
        private System.Windows.Forms.DataGridViewTextBoxColumn 培训人员;
        private System.Windows.Forms.DataGridViewTextBoxColumn 培训内容;
        private System.Windows.Forms.DataGridViewTextBoxColumn 培训成绩;
        private System.Windows.Forms.DataGridViewTextBoxColumn 培训地址;
        private System.Windows.Forms.DataGridViewTextBoxColumn 开始时间;
        private System.Windows.Forms.DataGridViewTextBoxColumn 结束时间;
    }
}