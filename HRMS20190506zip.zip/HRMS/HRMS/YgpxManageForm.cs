﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessModel;

namespace HRMS
{
    public partial class YgpxManageForm : Form
    {
        CommonHelper commonHelper = new CommonHelper();
        public YgpxManageForm()
        {
            InitializeComponent();
        }

        private void YgpxManageForm_Load(object sender, EventArgs e)
        {
            dtpBegin.Value = DateTime.Now.AddDays(-7);
            DataBind();
        }
        /// <summary>
        /// 绑定主表格数据
        /// </summary>
        public void DataBind()
        {
            string strSql = "";
            string beginDate = dtpBegin.Value.ToString("yyyy-MM-dd") + " 00:00:00";
            string endDate = dtpEnd.Value.ToString("yyyy-MM-dd") + " 23:59:59";
            if (beginDate.Trim() != "")
            {
                strSql = " AND  Start_date > '" + beginDate + "'  ";
            }
            if (endDate.Trim() != "")
            {
                strSql += " AND Start_date <= '" + endDate + "' ";
            }
            DataTable dt_Rypx = commonHelper.GetYgpxInfoListDetail(strSql);
            this.dgvYgpx.AutoGenerateColumns = false;
            this.dgvYgpx.DataSource = dt_Rypx;

            //判断是否有数据，有数据则将数量赋给数据量控件
            if (dgvYgpx != null)
            {
                this.lblCount.Text = dgvYgpx.Rows.Count.ToString();
            }
            else
            {
                this.lblCount.Text = "0";
            }
        }

        /// <summary>
        /// 增加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbAdd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new YgpxAddForm().ShowDialog();
            DataBind();
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbEdit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //判断是否有选中项
            if (this.dgvYgpx.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvYgpx.CurrentRow.Index;
                string strId = dgvYgpx.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                YgpxAddForm rf = new YgpxAddForm(strId, "Edit");
                //显示窗体
                rf.ShowDialog();
                DataBind();

            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            }         
        }

        /// <summary>
        /// 查看
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbView_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //判断是否有选中项
            if (this.dgvYgpx.SelectedRows.Count > 0)
            {
                //取出选中项的主键值
                int a = dgvYgpx.CurrentRow.Index;
                string strId = dgvYgpx.Rows[a].Cells[0].Value.ToString();
                //打出修改窗体                
                YgpxAddForm rf = new YgpxAddForm(strId, "View");
                //显示窗体
                rf.ShowDialog();
            }
            else
            {
                MessageBox.Show("没有选中任何项！");
            }         
        }

        /// <summary>
        /// 刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbRefresh_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DataBind();
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataBind();
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llbDelete_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ///让用户选择是否删除
            MessageBoxButtons btn = MessageBoxButtons.YesNoCancel;
            if (MessageBox.Show("确定要删除数据吗？", "删除数据", btn) == DialogResult.Yes)
            {
                //取出选中行里面绑定的对象
                int index = dgvYgpx.CurrentRow.Index;
                string strId = dgvYgpx.Rows[index].Cells[0].Value.ToString();
                try
                {
                    commonHelper.DeleteInfo("t_train", strId);
                    MessageBox.Show("删除成功！");
                    //确定删除的同时刷新数据
                    DataBind();
                }
                catch
                {
                    MessageBox.Show("删除失败！");
                }

            }
        }
    }
}
